#!/bin/bash
# Systemd service installation script for Minecraft servers
set -e

SERVER_ID=${SERVER_ID:-"default"}
SERVER_NAME=${SERVER_NAME:-"Minecraft Server"}
SERVER_DIR=${SERVER_DIR:-"/opt/minecraft/$SERVER_ID"}
SERVICE_USER=${SERVICE_USER:-"minecraft"}
MEMORY=${MEMORY:-"2G"}

echo "Installing systemd service for: $SERVER_NAME (ID: $SERVER_ID)"

# Create service user if not exists
if ! id "$SERVICE_USER" &>/dev/null; then
  echo "Creating user: $SERVICE_USER"
  sudo useradd -r -s /bin/false -d "$SERVER_DIR" "$SERVICE_USER"
fi

# Create server directory
sudo mkdir -p "$SERVER_DIR"
sudo chown -R "$SERVICE_USER:$SERVICE_USER" "$SERVER_DIR"

# Create systemd service file
SERVICE_FILE="/etc/systemd/system/minecraft-$SERVER_ID.service"
echo "Creating service file: $SERVICE_FILE"

sudo tee "$SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=Minecraft Server $SERVER_NAME
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/java -Xms$MEMORY -Xmx$MEMORY -jar server.jar nogui
Restart=on-failure
RestartSec=10

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$SERVER_DIR

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable service
echo "Enabling service..."
sudo systemctl enable "minecraft-$SERVER_ID.service"

echo "Service installed successfully!"
echo "Start the service with: sudo systemctl start minecraft-$SERVER_ID"
echo "Check status with: sudo systemctl status minecraft-$SERVER_ID"
echo "View logs with: sudo journalctl -u minecraft-$SERVERID -f"