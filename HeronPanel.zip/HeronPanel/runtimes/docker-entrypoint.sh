#!/bin/bash
# Docker entrypoint script for Minecraft servers
set -e

SERVER_ID=${SERVER_ID:-"default"}
SERVER_NAME=${SERVER_NAME:-"Minecraft Server"}
MEMORY=${MEMORY:-"2G"}
EULA=${EULA:-"FALSE"}

echo "Starting Minecraft Server: $SERVER_NAME (ID: $SERVER_ID)"
echo "Memory allocation: $MEMORY"

# Check EULA
if [ "$EULA" != "TRUE" ]; then
  echo "EULA must be set to TRUE to run the server"
  echo "Please set the EULA environment variable to TRUE"
  exit 1
fi

# Download server jar if not present
if [ ! -f server.jar ]; then
  echo "Downloading Minecraft server jar..."
  # Default to PaperMC
  curl -o server.jar https://api.papermc.io/v2/projects/paper/versions/latest/downloads/paper-latest.jar
fi

# Accept EULA
echo "eula=true" > eula.txt

# Start the server
echo "Starting server with $MEMORY memory..."
java -Xms$MEMORY -Xmx$MEMORY -jar server.jar nogui