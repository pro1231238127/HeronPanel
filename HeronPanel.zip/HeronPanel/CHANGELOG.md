# HeronPanel 3.0.0

- Replaced simulated Minecraft runtime with real `server.jar` execution.
- Added Docker daemon health checking and runtime fallback.
- Improved systemd user-service creation and graceful stop behavior.
- Added optional ttyd runtime.
- Added cross-platform host detection.
- Added secure server-root path resolution.
- Added allocation collision checks.
- Added request-size protection.
- Added Paper API/download timeouts.
- Added `/api/health`.
- Added Nebula Ultra visual layer and expanded themes.
- Added portable Linux/Windows startup scripts.
- Standardized server storage at `servers/<server-id>/`.
