import { createServer } from 'http';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, unlinkSync, rmdirSync, statSync, createReadStream } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join, basename } from 'path';
import { detectRuntime, getEnvironmentLabel } from './lib/environment.mjs';
import { downloadPaperJar, fetchPaperVersions, ensureServerFiles, writeServerProperties } from './lib/provision.mjs';
import { startServer, stopServer, sendCommand, isRunning } from './lib/process-manager.mjs';
import { readFileContent, listZipEntries, createZipArchive, collectFilesRecursive, saveUploadedFiles, safeResolve } from './lib/file-utils.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = process.env.PORT || 4173;
const DATA_DIR = join(__dirname, 'data');
const SERVERS_DIR = join(__dirname, 'servers');
const BACKUPS_DIR = join(DATA_DIR, 'backups');
const STATE_FILE = join(DATA_DIR, 'panel-state.json');
const PORT_START = Number(process.env.MC_PORT_START || 25565);
const MAX_BODY = 25 * 1024 * 1024;

[DATA_DIR, SERVERS_DIR, BACKUPS_DIR].forEach((dir) => {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
});

const mimeTypes = {
  '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.gif': 'image/gif', '.svg': 'image/svg+xml', '.mp4': 'video/mp4', '.ico': 'image/x-icon',
  '.zip': 'application/zip'
};

function getMimeType(filePath) {
  return mimeTypes[filePath.substring(filePath.lastIndexOf('.')).toLowerCase()] || 'application/octet-stream';
}

function serveStaticFile(res, filePath) {
  try {
    const fullPath = safeResolve(__dirname, filePath);
    if (!existsSync(fullPath)) {
      sendJsonResponse(res, 404, { ok: false, error: 'File not found' });
      return;
    }
    const content = readFileSync(fullPath);
    res.writeHead(200, { 'Content-Type': getMimeType(filePath), 'Content-Length': content.length });
    res.end(content);
  } catch (error) {
    sendJsonResponse(res, 500, { ok: false, error: error.message });
  }
}

function serveDownload(res, filePath, filename) {
  if (!existsSync(filePath)) {
    sendJsonResponse(res, 404, { ok: false, error: 'File not found' });
    return;
  }
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Access-Control-Allow-Origin': '*'
  });
  createReadStream(filePath).pipe(res);
}

const defaultState = {
  settings: {
    panelName: 'HeronPanel',
    serverCost: 100,
    maxServers: 5,
    clickTarget: 100,
    clickReward: 10,
    motd: 'Welcome to our Minecraft Server!',
    theme: 'nebula',
    defaultRam: 2,
    defaultCpu: 100,
    defaultDisk: 10,
    local: true,
    pterodactyl: false,
    codesandbox: true,
    github: true,
    vps: true,
    providers: { local: true, pterodactyl: false, codesandbox: true, github: true, vps: true },
    ui: {
      compactMode: false,
      animations: true,
      fontSize: 'medium',
      accentIntensity: 'normal',
      sidebarStyle: 'default',
      consoleTheme: 'dark',
      blurBackground: true
    },
    features: {
      advancedConsole: true, realTimeStats: true, autoBackups: true,
      pluginMarketplace: true, customThemes: true, webTerminal: true,
      dockerSupport: true, systemdSupport: true, ttydSupport: true,
      serverDownload: true, playerManagement: true, scheduleTasks: true,
      subuserAccess: true, databaseManager: true, networkAllocation: true,
      modInstaller: true, worldEditor: true, apiAccess: true
    },
    sessionTimeout: 60,
    maxLoginAttempts: 5,
    requireEmailVerification: false,
    enableTwoFactor: false,
    consoleLineLimit: 500,
    fileUploadLimit: 100
  },
  coins: 1000,
  clickProgress: 0,
  users: [{ id: 'admin', username: 'admin', email: 'admin@heronpanel.local', password: 'admin123', role: 'admin' }],
  servers: [],
  activity: [],
  players: [],
  pluginCatalog: [],
  modCatalog: [],
  selectedServerId: null,
  runtime: null
};

function normalizeState(state) {
  state.settings = { ...defaultState.settings, ...state.settings };
  state.settings.features = { ...defaultState.settings.features, ...state.settings.features };
  state.settings.ui = { ...defaultState.settings.ui, ...state.settings.ui };
  state.settings.providers = state.settings.providers || {
    local: state.settings.local !== false,
    pterodactyl: !!state.settings.pterodactyl,
    codesandbox: state.settings.codesandbox !== false,
    github: state.settings.github !== false,
    vps: state.settings.vps !== false
  };
  state.players = state.players || [];
  state.pluginCatalog = state.pluginCatalog || [];
  state.modCatalog = state.modCatalog || [];
  return state;
}

function loadState() {
  try {
    if (existsSync(STATE_FILE)) {
      return normalizeState(JSON.parse(readFileSync(STATE_FILE, 'utf8')));
    }
  } catch {
    console.log('Creating new state file');
  }
  return normalizeState(structuredClone(defaultState));
}

function saveState(state) {
  writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

let currentState = loadState();
currentState.runtime = detectRuntime();
currentState.runtime.label = getEnvironmentLabel(currentState.runtime);
saveState(currentState);

function sendJsonResponse(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function getUser(token) {
  return token ? currentState.users.find((u) => u.id === token) : null;
}

function requireAuth(res, token) {
  const user = getUser(token);
  if (!user) {
    sendJsonResponse(res, 401, { ok: false, error: 'Invalid token' });
    return null;
  }
  return user;
}

function getServer(id) {
  return currentState.servers.find((s) => s.id === id);
}

function serverDir(id) {
  if (!/^[a-zA-Z0-9_-]+$/.test(String(id))) throw new Error('Invalid server id');
  return join(SERVERS_DIR, id);
}

function allocatePort() {
  const used = new Set(currentState.servers.map(s => Number(String(s.allocation || '').split(':').pop())).filter(Boolean));
  let port = PORT_START;
  while (used.has(port) && port < PORT_START + 10000) port++;
  if (port >= PORT_START + 10000) throw new Error('No free Minecraft allocation found.');
  return port;
}

function addActivity(msg) {
  currentState.activity.unshift(msg);
  if (currentState.activity.length > 100) currentState.activity.pop();
}

function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'GET' && !url.pathname.startsWith('/api/')) {
    serveStaticFile(res, url.pathname === '/' ? '/index.html' : url.pathname);
    return;
  }
  let body = '';
  req.on('data', (chunk) => {
    if (body.length > MAX_BODY) return;
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      if (body.length > MAX_BODY) return sendJsonResponse(res, 413, { ok: false, error: 'Request body too large' });
      handleApiRequest(req, res, req.method, url.pathname, body ? JSON.parse(body) : {}, url);
    } catch (error) {
      sendJsonResponse(res, 400, { ok: false, error: error.message || 'Invalid JSON' });
    }
  });
}

function handleApiRequest(req, res, method, path, body, url) {
  if (method === 'OPTIONS') return sendJsonResponse(res, 200, { ok: true });

  const token = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.slice(7) : null;

  const routes = [
    ['POST', '/api/login', () => handleLogin(res, body)],
    ['POST', '/api/auth/login', () => handleLogin(res, body)],
    ['POST', '/api/register', () => handleRegister(res, body)],
    ['POST', '/api/auth/register', () => handleRegister(res, body)],
    ['POST', '/api/auth/logout', () => sendJsonResponse(res, 200, { ok: true })],
    ['GET', '/api/state', () => handleGetState(res, token)],
    ['GET', '/api/runtime', () => sendJsonResponse(res, 200, { ok: true, runtime: detectRuntime() })],
    ['GET', '/api/health', () => sendJsonResponse(res, 200, { ok: true, version: '3.0.0', uptime: process.uptime(), runtime: detectRuntime(), serverRoot: SERVERS_DIR })],
    ['POST', '/api/admin/settings', () => handleAdminSettings(res, body, token)],
    ['POST', '/api/account', () => handleAccount(res, body, token)],
    ['POST', '/api/account/settings', () => handleAccount(res, body, token)],
    ['POST', '/api/click', () => handleClick(res, token)],
    ['POST', '/api/broadcast', () => handleBroadcast(res, body, token)],
    ['POST', '/api/marketplace/buy-server-limit', () => handleBuyServerLimit(res, token)],
    ['POST', '/api/marketplace/server-limit', () => handleBuyServerLimit(res, token)],
    ['GET', '/api/paper/versions', () => handlePaperVersions(res)],
    ['GET', '/api/catalog/search', () => handleCatalogSearch(res, url.searchParams)],
    ['POST', '/api/servers', () => handleCreateServer(res, body, token)],
  ];

  for (const [m, p, fn] of routes) {
    if (method === m && path === p) return fn();
  }

  const serverMatch = path.match(/^\/api\/servers\/([^/]+)(\/.*)?$/);
  if (serverMatch) {
    const id = serverMatch[1];
    const sub = serverMatch[2] || '';
    return handleServerRoute(res, method, id, sub, body, url, token);
  }

  const playerMatch = path.match(/^\/api\/players\/([^/]+)\/action$/);
  if (playerMatch && method === 'POST') {
    return handlePlayerAction(res, playerMatch[1], body, token);
  }

  sendJsonResponse(res, 404, { ok: false, error: 'Not found' });
}

function handleServerRoute(res, method, id, sub, body, url, token) {
  if (!requireAuth(res, token)) return;
  const server = getServer(id);
  if (!server && sub !== '') return sendJsonResponse(res, 404, { ok: false, error: 'Server not found' });

  const dir = serverDir(id);

  if (sub === '' && method === 'DELETE') return handleDeleteServer(res, id);
  if (sub === '/power' && method === 'POST') return handleServerPower(res, server, body);
  if ((sub === '/console' || sub === '/command') && method === 'POST') return handleServerConsole(res, server, body);
  if (sub === '/files' && method === 'GET') return handleGetFiles(res, server, url.searchParams, dir);
  if (sub === '/files' && method === 'POST') return handleFileOperation(res, server, body, dir);
  if (sub === '/file' && method === 'GET') return handleReadFile(res, server, url.searchParams, dir);
  if (sub === '/file' && method === 'POST') return handleSaveFile(res, server, body, dir);
  if (sub === '/file/delete' && method === 'POST') return handleDeleteFile(res, server, body, dir);
  if (sub === '/folder' && method === 'POST') return handleCreateFolder(res, server, body, dir);
  if (sub === '/upload' && method === 'POST') return handleUpload(res, server, body, dir);
  if (sub === '/settings' && method === 'POST') return handleServerSettings(res, server, body, dir);
  if (sub === '/identity' && method === 'POST') return handleServerIdentity(res, server, body, dir);
  if (sub === '/icon' && method === 'POST') return handleServerIcon(res, server, body, dir);
  if (sub === '/environment' && method === 'POST') return handleServerEnvironment(res, server, body);
  if (sub === '/backup' && method === 'POST') return handleBackup(res, server, dir);
  if (sub === '/network' && method === 'POST') return handleNetwork(res, server, body);
  if (sub === '/databases' && method === 'POST') return handleDatabase(res, server, body);
  if (sub === '/schedules' && method === 'POST') return handleSchedule(res, server, body);
  if (sub === '/startup' && method === 'POST') return handleStartup(res, server, body);
  if (sub === '/subusers' && method === 'POST') return handleSubuser(res, server, body);
  if (sub === '/players' && method === 'POST') return handleAddPlayer(res, server, body, dir);
  if (sub === '/install' && method === 'POST') return handleInstall(res, server, body, dir);
  if (sub === '/install-external' && method === 'POST') return handleInstallExternal(res, server, body, dir);
  if (sub === '/install-plugin' && method === 'POST') return handleInstallExternal(res, server, body, dir);
  if (sub === '/remove' && method === 'POST') return handleRemoveResource(res, server, body, dir);
  if (sub === '/zip' && method === 'GET') return handleZipList(res, server, url.searchParams, dir);
  if (sub === '/zip/file' && method === 'GET') return handleZipFile(res, server, url.searchParams, dir);
  if (sub === '/zip/extract' && method === 'POST') return handleZipExtract(res, server, body, dir);
  if (sub === '/download' && method === 'GET') return handleServerDownload(res, server, url.searchParams, dir);

  sendJsonResponse(res, 404, { ok: false, error: 'Not found' });
}

function handleLogin(res, body) {
  const user = currentState.users.find((u) =>
    (u.username === body.identifier || u.email === body.identifier) && u.password === body.password
  );
  if (!user) return sendJsonResponse(res, 401, { ok: false, error: 'Invalid credentials' });
  sendJsonResponse(res, 200, { ok: true, token: user.id, user: { ...user, password: undefined } });
}

function handleRegister(res, body) {
  const { username, email, password } = body;
  if (currentState.users.find((u) => u.username === username || u.email === email)) {
    return sendJsonResponse(res, 400, { ok: false, error: 'User already exists' });
  }
  const newUser = { id: Date.now().toString(), username, email, password, role: 'user' };
  currentState.users.push(newUser);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, token: newUser.id, user: { ...newUser, password: undefined } });
}

function handleGetState(res, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  currentState.runtime = detectRuntime();
  sendJsonResponse(res, 200, { ok: true, state: currentState, user: { ...user, password: undefined } });
}

function handleAdminSettings(res, body, token) {
  const user = requireAuth(res, token);
  if (!user || user.role !== 'admin') return sendJsonResponse(res, 403, { ok: false, error: 'Admin only' });
  currentState.settings = normalizeState({ settings: { ...currentState.settings, ...body } }).settings;
  if (body.local !== undefined) currentState.settings.providers.local = body.local;
  if (body.pterodactyl !== undefined) currentState.settings.providers.pterodactyl = body.pterodactyl;
  if (body.codesandbox !== undefined) currentState.settings.providers.codesandbox = body.codesandbox;
  if (body.github !== undefined) currentState.settings.providers.github = body.github;
  if (body.vps !== undefined) currentState.settings.providers.vps = body.vps;
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleAccount(res, body, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  const idx = currentState.users.findIndex((u) => u.id === token);
  if (body.currentPassword && currentState.users[idx].password !== body.currentPassword) {
    return sendJsonResponse(res, 400, { ok: false, error: 'Current password incorrect' });
  }
  if (body.username) currentState.users[idx].username = body.username;
  if (body.email) currentState.users[idx].email = body.email;
  if (body.newPassword) currentState.users[idx].password = body.newPassword;
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, user: { ...currentState.users[idx], password: undefined } });
}

function handleClick(res, token) {
  if (!requireAuth(res, token)) return;
  currentState.clickProgress = (currentState.clickProgress || 0) + 1;
  const target = currentState.settings.clickTarget || 100;
  if (currentState.clickProgress >= target) {
    currentState.coins += currentState.settings.clickReward || 10;
    currentState.clickProgress = 0;
    addActivity(`Earned ${currentState.settings.clickReward} coins from clicking!`);
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleBroadcast(res, body, token) {
  if (!requireAuth(res, token)) return;
  addActivity(`Broadcast: ${body.message}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleBuyServerLimit(res, token) {
  if (!requireAuth(res, token)) return;
  if (currentState.coins < 1000) return sendJsonResponse(res, 400, { ok: false, error: 'Not enough coins' });
  currentState.coins -= 1000;
  currentState.settings.maxServers += 1;
  addActivity(`Increased server limit to ${currentState.settings.maxServers}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

async function handlePaperVersions(res) {
  const versions = await fetchPaperVersions();
  sendJsonResponse(res, 200, { ok: true, versions });
}

function handleCatalogSearch(res, params) {
  const query = (params.get('query') || '').toLowerCase();
  const type = params.get('type') || 'plugin';
  const catalog = type === 'mod' ? currentState.modCatalog : currentState.pluginCatalog;
  const defaults = [
    { id: 'essentials', name: 'EssentialsX', author: 'Essentials Team', description: 'Essential commands for servers', downloads: 5000000 },
    { id: 'worldedit', name: 'WorldEdit', author: 'EngineHub', description: 'In-game world editor', downloads: 8000000 },
    { id: 'luckperms', name: 'LuckPerms', author: 'Luck', description: 'Advanced permissions', downloads: 6000000 },
    { id: 'vault', name: 'Vault', author: 'MilkBowl', description: 'Economy API bridge', downloads: 9000000 },
    { id: 'coreprotect', name: 'CoreProtect', author: 'Intelli', description: 'Block logging and rollback', downloads: 4000000 }
  ];
  const pool = catalog.length ? catalog : defaults;
  const results = pool.filter((item) =>
    !query || item.name?.toLowerCase().includes(query) || item.description?.toLowerCase().includes(query)
  ).slice(0, Number(params.get('limit') || 12));
  sendJsonResponse(res, 200, { ok: true, results });
}

async function handleCreateServer(res, body, token) {
  const user = requireAuth(res, token);
  if (!user) return;

  if (user.role !== 'admin' && currentState.servers.length >= currentState.settings.maxServers) {
    return sendJsonResponse(res, 400, { ok: false, error: 'Server limit reached' });
  }
  if (currentState.coins < currentState.settings.serverCost) {
    return sendJsonResponse(res, 400, { ok: false, error: 'Not enough coins' });
  }

  const {
    name, egg, provider, region, runtime, paperVersion,
    ram, cpu, disk, autoStart, environment
  } = body;

  const serverId = Date.now().toString();
  const dir = serverDir(serverId);
  mkdirSync(dir, { recursive: true });

  const port = allocatePort();
  const runtimeInfo = detectRuntime();

  const server = {
    id: serverId,
    name,
    egg: egg || 'Minecraft Java Paper',
    provider: provider || 'local',
    region: region || 'Auto',
    runtime: runtime || 'Java 21',
    ram: parseInt(ram, 10) || currentState.settings.defaultRam || 2,
    cpu: parseInt(cpu, 10) || currentState.settings.defaultCpu || 100,
    disk: parseInt(disk, 10) || currentState.settings.defaultDisk || 10,
    allocation: `127.0.0.1:${port}`,
    status: 'provisioning',
    console: [`[HeronPanel] Provisioning server "${name}"...`],
    files: [],
    startup: {
      command: `java -Xms{{SERVER_MEMORY}}G -Xmx{{SERVER_MEMORY}}G -jar server.jar nogui`,
      variables: { MC_VERSION: paperVersion || 'latest', EULA: 'TRUE' }
    },
    environment: { environment: environment || 'auto', config: {} },
    runtimeEnv: environment || 'auto',
    databases: [],
    schedules: [],
    subusers: [],
    backups: [],
    downloadHistory: [],
    settings: {
      motd: currentState.settings.motd,
      icon: '',
      whitelist: [],
      ops: [],
      banned: []
    },
    paperVersion: paperVersion || 'latest',
    provisionStatus: 'downloading',
    createdAt: new Date().toISOString()
  };

  currentState.coins -= currentState.settings.serverCost;
  currentState.servers.push(server);
  currentState.selectedServerId = serverId;
  addActivity(`Creating server: ${name}`);
  saveState(currentState);

  sendJsonResponse(res, 200, { ok: true, state: currentState, server });

  try {
    ensureServerFiles(dir, server);
    const result = await downloadPaperJar(dir, paperVersion || 'latest');
    server.console.push(`[HeronPanel] Downloaded Paper ${result.mcVersion} build ${result.buildNum}`);
    server.console.push(`[HeronPanel] Server files ready in servers/${serverId}/`);
    server.provisionStatus = 'ready';
    server.status = 'offline';
    server.paperVersion = result.mcVersion;

    if (autoStart) {
      startServer(server, dir, () => saveState(currentState));
      server.status = 'starting';
      server.console.push(`[HeronPanel] Auto-start enabled (${runtimeInfo.docker ? 'docker' : 'local'})`);
    }
  } catch (err) {
    server.console.push(`[HeronPanel] Provision warning: ${err.message}`);
    server.console.push('[HeronPanel] Place server.jar manually in servers folder to start');
    server.provisionStatus = 'partial';
    server.status = 'offline';
  }
  saveState(currentState);
}

function handleDeleteServer(res, id) {
  stopServer(id);
  const idx = currentState.servers.findIndex((s) => s.id === id);
  if (idx === -1) return sendJsonResponse(res, 404, { ok: false, error: 'Server not found' });

  const dir = serverDir(id);
  try {
    if (existsSync(dir)) deleteFolderRecursive(dir);
  } catch (e) {
    console.error('Delete error:', e.message);
  }

  const name = currentState.servers[idx].name;
  currentState.servers.splice(idx, 1);
  addActivity(`Deleted server: ${name}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function deleteFolderRecursive(dir) {
  for (const file of readdirSync(dir)) {
    const fp = join(dir, file);
    if (statSync(fp).isDirectory()) deleteFolderRecursive(fp);
    else unlinkSync(fp);
  }
  rmdirSync(dir);
}

function handleServerPower(res, server, body) {
  const dir = serverDir(server.id);
  const onUpdate = () => saveState(currentState);

  switch (body.action) {
    case 'start':
      if (isRunning(server.id)) return sendJsonResponse(res, 400, { ok: false, error: 'Already running' });
      try {
        startServer(server, dir, onUpdate);
        addActivity(`Started server: ${server.name}`);
      } catch (e) {
        return sendJsonResponse(res, 500, { ok: false, error: e.message });
      }
      break;
    case 'stop':
      stopServer(server.id);
      server.status = 'offline';
      addActivity(`Stopped server: ${server.name}`);
      break;
    case 'restart':
      stopServer(server.id);
      server.status = 'restarting';
      setTimeout(() => {
        startServer(server, dir, onUpdate);
        saveState(currentState);
      }, 2000);
      addActivity(`Restarted server: ${server.name}`);
      break;
    case 'kill':
      stopServer(server.id, 'SIGKILL');
      server.status = 'offline';
      break;
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerConsole(res, server, body) {
  if (sendCommand(server.id, body.command)) {
    server.console.push(`> ${body.command}`);
  } else {
    server.console.push(`[Error] Server not running — command queued: ${body.command}`);
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleGetFiles(res, server, params, dir) {
  const relPath = params.get('path') || '.';
  const target = safeResolve(dir, relPath === '.' ? '' : relPath);
  try {
    const files = readdirSync(target).map((file) => {
      const fp = join(target, file);
      const stats = statSync(fp);
      return {
        name: file,
        path: join(relPath === '.' ? '' : relPath, file).replace(/\\/g, '/').replace(/^\//, '') || file,
        size: stats.size,
        type: stats.isDirectory() ? 'Folder' : 'File',
        modified: stats.mtime
      };
    });
    sendJsonResponse(res, 200, { ok: true, files, path: relPath });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleReadFile(res, server, params, dir) {
  try {
    const path = params.get('path') || '';
    const content = readFileContent(dir, path);
    sendJsonResponse(res, 200, { ok: true, path, content });
  } catch (e) {
    sendJsonResponse(res, 404, { ok: false, error: e.message });
  }
}

function handleSaveFile(res, server, body, dir) {
  try {
    const target = safeResolve(dir, body.path);
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, body.content ?? '');
    sendJsonResponse(res, 200, { ok: true });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleDeleteFile(res, server, body, dir) {
  try {
    const target = safeResolve(dir, body.path);
    if (statSync(target).isDirectory()) deleteFolderRecursive(target);
    else unlinkSync(target);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleCreateFolder(res, server, body, dir) {
  try {
    mkdirSync(safeResolve(dir, body.path), { recursive: true });
    sendJsonResponse(res, 200, { ok: true });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleUpload(res, server, body, dir) {
  try {
    saveUploadedFiles(dir, body.targetPath || '.', body.files || []);
    addActivity(`Uploaded ${body.files?.length || 0} files to ${server.name}`);
    saveState(currentState);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleFileOperation(res, server, body, dir) {
  handleSaveFile(res, server, { path: body.path, content: body.content }, dir);
}

function handleServerSettings(res, server, body, dir) {
  Object.assign(server.settings, body);
  if (body.ram) server.ram = body.ram;
  if (body.cpu) server.cpu = body.cpu;
  if (body.disk) server.disk = body.disk;
  if (body.name) server.name = body.name;
  writeServerProperties(dir, server, body);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerIdentity(res, server, body, dir) {
  if (body.motd) {
    server.settings.motd = body.motd;
    writeServerProperties(dir, server, { motd: body.motd });
  }
  if (body.iconDataUrl) {
    const data = body.iconDataUrl.replace(/^data:image\/\w+;base64,/, '');
    writeFileSync(join(dir, 'server-icon.png'), Buffer.from(data, 'base64'));
    server.settings.icon = body.iconDataUrl;
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerIcon(res, server, body, dir) {
  handleServerIdentity(res, server, { iconDataUrl: body.icon, motd: server.settings.motd }, dir);
}

function handleServerEnvironment(res, server, body) {
  server.environment = { environment: body.environment, config: body.config || {} };
  server.runtimeEnv = body.environment;
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleBackup(res, server, dir) {
  const backupName = `backup-${server.id}-${Date.now()}.zip`;
  const backupPath = join(BACKUPS_DIR, backupName);
  try {
    createZipArchive(dir, backupPath);
    const entry = { id: Date.now().toString(), name: backupName, date: new Date().toISOString(), size: statSync(backupPath).size };
    server.backups = server.backups || [];
    server.backups.unshift(entry);
    addActivity(`Backup created for ${server.name}`);
    saveState(currentState);
    sendJsonResponse(res, 200, { ok: true, state: currentState, backup: entry });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleNetwork(res, server, body) {
  if (body.port) {
    const port = Number(body.port);
    if (!Number.isInteger(port) || port < 1024 || port > 65535) return sendJsonResponse(res, 400, { ok: false, error: 'Port must be between 1024 and 65535.' });
    const conflict = currentState.servers.some(s => s.id !== server.id && Number(String(s.allocation || '').split(':').pop()) === port);
    if (conflict) return sendJsonResponse(res, 409, { ok: false, error: 'That port is already allocated to another server.' });
    server.allocation = `127.0.0.1:${port}`;
  }
  server.network = { ...server.network, ...body };
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleDatabase(res, server, body) {
  server.databases = server.databases || [];
  server.databases.push({ id: Date.now().toString(), ...body, createdAt: new Date().toISOString() });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleSchedule(res, server, body) {
  server.schedules = server.schedules || [];
  server.schedules.push({ id: Date.now().toString(), ...body, enabled: true });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleStartup(res, server, body) {
  if (body.command) server.startup.command = body.command;
  if (body.paperVersion) server.startup.variables.MC_VERSION = body.paperVersion;
  if (body.variablesText) {
    for (const line of body.variablesText.split('\n')) {
      const [k, ...v] = line.split('=');
      if (k) server.startup.variables[k.trim()] = v.join('=').trim();
    }
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleSubuser(res, server, body) {
  server.subusers = server.subusers || [];
  server.subusers.push({ id: Date.now().toString(), ...body });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleAddPlayer(res, server, body, dir) {
  currentState.players = currentState.players || [];
  const player = { id: Date.now().toString(), serverId: server.id, ...body };
  currentState.players.push(player);
  if (body.whitelisted) {
    const wlPath = join(dir, 'whitelist.json');
    const wl = existsSync(wlPath) ? JSON.parse(readFileSync(wlPath, 'utf8')) : [];
    if (!wl.find((p) => p.name === body.name)) wl.push({ uuid: player.id, name: body.name });
    writeFileSync(wlPath, JSON.stringify(wl, null, 2));
  }
  if (body.role === 'op') {
    const opsPath = join(dir, 'ops.json');
    const ops = existsSync(opsPath) ? JSON.parse(readFileSync(opsPath, 'utf8')) : [];
    if (!ops.find((p) => p.name === body.name)) ops.push({ uuid: player.id, name: body.name, level: 4 });
    writeFileSync(opsPath, JSON.stringify(ops, null, 2));
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handlePlayerAction(res, playerId, body, token) {
  if (!requireAuth(res, token)) return;
  const player = currentState.players.find((p) => p.id === playerId);
  if (!player) return sendJsonResponse(res, 404, { ok: false, error: 'Player not found' });
  if (body.action === 'ban') player.banned = true;
  if (body.action === 'unban') player.banned = false;
  if (body.action === 'kick') addActivity(`Kicked player ${player.name}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

async function handleInstallExternal(res, server, body, dir) {
  const pluginsDir = join(dir, 'plugins');
  mkdirSync(pluginsDir, { recursive: true });
  const name = body.name || body.url?.split('/').pop() || `${body.id || 'plugin'}.jar`;
  try {
    if (body.url) {
      const resp = await fetch(body.url);
      const buf = Buffer.from(await resp.arrayBuffer());
      writeFileSync(join(pluginsDir, name.endsWith('.jar') ? name : `${name}.jar`), buf);
    } else {
      writeFileSync(join(pluginsDir, `${body.id || name}.jar`), Buffer.from(''));
    }
    addActivity(`Installed ${name} on ${server.name}`);
    saveState(currentState);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleInstall(res, server, body, dir) {
  handleInstallExternal(res, server, { id: body.itemId, name: `${body.itemId}.jar` }, dir);
}

function handleRemoveResource(res, server, body, dir) {
  if (body.type === 'schedule') server.schedules = (server.schedules || []).filter((s) => s.id !== body.id);
  if (body.type === 'database') server.databases = (server.databases || []).filter((d) => d.id !== body.id);
  if (body.type === 'subuser') server.subusers = (server.subusers || []).filter((u) => u.id !== body.id);
  if (body.type === 'backup') server.backups = (server.backups || []).filter((b) => b.id !== body.id);
  if (body.type === 'player') currentState.players = (currentState.players || []).filter((p) => p.id !== body.id);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleZipList(res, server, params, dir) {
  const zipPath = safeResolve(dir, params.get('path') || '');
  const entries = listZipEntries(zipPath);
  sendJsonResponse(res, 200, { ok: true, path: params.get('path'), dir: params.get('dir') || '', entries });
}

function handleZipFile(res, server, params, dir) {
  sendJsonResponse(res, 200, {
    ok: true,
    entry: params.get('entry'),
    content: `[Preview unavailable for ${params.get('entry')}]`
  });
}

function handleZipExtract(res, server, body, dir) {
  addActivity(`Extract requested for ${body.entry || body.path} on ${server.name}`);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleServerDownload(res, server, params, dir) {
  const type = params.get('type') || 'full';
  const tmpZip = join(BACKUPS_DIR, `download-${server.id}-${Date.now()}.zip`);

  try {
    const filter = type === 'world'
      ? (rel) => rel.startsWith('world')
      : type === 'config'
        ? (rel) => /\.(properties|json|yml|yaml|txt)$/i.test(rel)
        : null;

    if (filter) {
      const files = collectFilesRecursive(dir, dir, filter);
      mkdirSync(join(tmpZip, '..'), { recursive: true });
      createZipArchive(dir, tmpZip, filter);
    } else {
      createZipArchive(dir, tmpZip);
    }

    server.downloadHistory = server.downloadHistory || [];
    server.downloadHistory.unshift({
      type,
      date: new Date().toLocaleDateString(),
      size: `${Math.round(statSync(tmpZip).size / 1024 / 1024)} MB`,
      status: 'completed'
    });
    saveState(currentState);

    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${server.name}-${type}.zip"`,
      'Access-Control-Allow-Origin': '*'
    });
    createReadStream(tmpZip).pipe(res);
  } catch (e) {
    sendJsonResponse(res, 200, {
      ok: true,
      message: 'Download ready',
      downloadPath: dir,
      serverName: server.name,
      note: e.message
    });
  }
}

createServer(handleRequest).listen(PORT, () => {
  const rt = detectRuntime();
  console.log(`\n  ╔══════════════════════════════════════════╗`);
  console.log(`  ║  HeronPanel Ultra v3.0 — Nebula Edition  ║`);
  console.log(`  ╚══════════════════════════════════════════╝`);
  console.log(`  URL:      http://127.0.0.1:${PORT}`);
  console.log(`  Servers:  ${SERVERS_DIR}`);
  console.log(`  Runtime:  ${getEnvironmentLabel(rt)}`);
  console.log(`  Java:     ${rt.java ? 'Yes' : 'No'}  Docker: ${rt.docker ? 'Yes' : 'No'}`);
  console.log(`  Systemd:  ${rt.systemd ? 'Yes' : 'No'}  TTYd:   ${rt.ttyd ? 'Yes' : 'No'}`);
  console.log(`  Login:    admin / admin123\n`);
});
