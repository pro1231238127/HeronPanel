# HeronPanel 3.0 — Nebula Ultra

A portable Minecraft server management panel designed to run from a normal Linux VPS, Windows PC, macOS, GitHub Codespaces, or CodeSandbox-like containers.

## What changed

- **Real server execution:** the panel launches the real `server.jar` / Paper jar; the old simulated launcher is gone.
- **Runtime fallback:** `auto` tries Docker, then systemd, then local Java. If a selected runtime fails, the panel reports the reason and can fall back to local Java.
- **TTYd support:** optional terminal wrapper when `ttyd` and Java are available.
- **Portable environment detection:** Linux, Windows, macOS, GitHub Codespaces and CodeSandbox are detected.
- **Dedicated server storage:** every server is created under `HeronPanel/servers/<server-id>/`.
- **Collision-safe allocations:** panel allocations start at port `25565` and avoid ports already assigned to another panel server.
- **Safer file manager:** server file paths are constrained to the server directory, blocking `../` traversal.
- **Real ZIP backups/downloads:** full, world and config exports.
- **Paper provisioning:** bounded network timeouts and clearer API/download failures.
- **Health API:** `GET /api/health`.
- **Nebula Ultra UI:** animated glass panels, responsive tabs, glow states, reduced-motion support and existing theme system.

## Compatibility reality

No panel can make a missing host capability magically exist. For example, Docker requires a working Docker daemon; systemd requires Linux + a usable systemd user manager; ttyd requires the `ttyd` binary. HeronPanel therefore detects capabilities and uses a compatible fallback instead of crashing.

For Minecraft Java servers, **Java is still required** unless Docker is being used with an image that supplies its own Java runtime.

## Start

### Linux / VPS / Codespaces / CodeSandbox

```bash
cd HeronPanel
bash scripts/start-linux.sh
```

Or:

```bash
npm install
npm start
```

Open `http://127.0.0.1:4173`.

### Windows

Run PowerShell:

```powershell
cd HeronPanel
.\scripts\start-windows.ps1
```

### Host diagnostics

```bash
bash scripts/check-host.sh
```

## Default login

`admin / admin123`

**Change the default password before exposing the panel to the internet.** This build is intended as a development/self-hosted panel and does not claim to provide production-grade authentication, TLS, isolation or a full remote-provider implementation.

## Server lifecycle

1. Create a Minecraft Java Paper server in the panel.
2. Paper is downloaded into `servers/<id>/server.jar`.
3. `eula.txt`, `server.properties`, `plugins/` and the basic Minecraft files are created.
4. Start uses the selected runtime or `auto` fallback.
5. The console is connected to the actual process/container.
6. Stop sends a graceful signal where supported.
7. Backups and downloads are stored in `data/backups/`.

## Important

Do not run the panel as a privileged root service on an internet-facing host without adding authentication hardening, HTTPS/reverse proxy, process isolation and OS-level resource limits.
