$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js 18+ is required." }
node --check server.mjs
npm install
New-Item -ItemType Directory -Force servers, data\backups | Out-Null
if (-not $env:PORT) { $env:PORT = "4173" }
Write-Host "Starting HeronPanel on port $env:PORT..."
npm start
