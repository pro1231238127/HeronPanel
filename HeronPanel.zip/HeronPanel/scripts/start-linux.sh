#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo "Node.js 18+ required"; exit 1; }
node --check server.mjs
npm install
mkdir -p servers data/backups
echo "Starting HeronPanel on port ${PORT:-4173}..."
exec npm start
