#!/usr/bin/env bash
set +e
echo "=== HeronPanel host check ==="
for c in node java docker systemctl ttyd unzip zip; do
  if command -v "$c" >/dev/null 2>&1; then echo "[OK] $c: $(command -v "$c")"; else echo "[--] $c: not found"; fi
done
node -v 2>/dev/null || true
java -version 2>&1 | head -n 1
echo "============================="
