#!/usr/bin/env node
/**
 * Standalone launcher used by HeronPanel when you want a simple, portable
 * Minecraft process. It executes the real server.jar from the current folder.
 */
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const dir = process.cwd();
const jar = existsSync(join(dir, 'server.jar')) ? 'server.jar' : 'paper.jar';
const ram = Math.max(1, Number.parseInt(process.env.SERVER_RAM || process.argv[2] || '2', 10) || 2);

if (!existsSync(join(dir, jar))) {
  console.error(`[HeronPanel] ${jar} not found in ${dir}`);
  console.error('[HeronPanel] Put a real Minecraft/Paper server jar in this server folder.');
  process.exit(2);
}

const child = spawn(process.env.JAVA_BIN || 'java', [`-Xms${ram}G`, `-Xmx${ram}G`, '-jar', jar, 'nogui'], {
  cwd: dir, stdio: 'inherit', shell: process.platform === 'win32'
});
child.on('exit', (code, signal) => process.exit(code ?? (signal ? 1 : 0)));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => child.kill(sig));
