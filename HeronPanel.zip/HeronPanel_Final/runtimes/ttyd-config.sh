#!/bin/bash
# TTYd configuration script for web-based terminal access
set -e

SERVER_ID=${SERVER_ID:-"default"}
SERVER_NAME=${SERVER_NAME:-"Minecraft Server"}
TTYD_PORT=${TTYD_PORT:-"7681"}
SERVER_DIR=${SERVER_DIR:-"/opt/minecraft/$SERVER_ID"}
CREDENTIALS=${CREDENTIALS:-"admin:admin"}

echo "Configuring TTYd for: $SERVER_NAME (ID: $SERVER_ID)"
echo "TTYd will run on port: $TTYD_PORT"

# Install TTYd if not present
if ! command -v ttyd &> /dev/null; then
  echo "Installing TTYd..."
  if command -v apt-get &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y ttyd
  elif command -v yum &> /dev/null; then
    sudo yum install -y ttyd
  else
    echo "Please install TTYd manually for your distribution"
    exit 1
  fi
fi

# Create TTYd systemd service
TTYD_SERVICE_FILE="/etc/systemd/system/ttyd-$SERVER_ID.service"
echo "Creating TTYd service file: $TTYD_SERVICE_FILE"

sudo tee "$TTYD_SERVICE_FILE" > /dev/null <<EOF
[Unit]
Description=TTYd Web Terminal for $SERVER_NAME
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$SERVER_DIR
ExecStart=/usr/bin/ttyd -p $TTYD_PORT -c $CREDENTIALS bash
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
echo "Reloading systemd daemon..."
sudo systemctl daemon-reload

# Enable service
echo "Enabling TTYd service..."
sudo systemctl enable "ttyd-$SERVER_ID.service"

echo "TTYd configured successfully!"
echo "Start the service with: sudo systemctl start ttyd-$SERVER_ID"
echo "Access web terminal at: http://localhost:$TTYD_PORT"
echo "Default credentials: $CREDENTIALS"
echo ""
echo "To customize:"
echo "- Change port: Set TTYD_PORT environment variable"
echo "- Change credentials: Set CREDENTIALS environment variable (format: user:password)"