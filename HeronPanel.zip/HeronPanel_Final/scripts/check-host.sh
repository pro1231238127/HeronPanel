#!/usr/bin/env bash
set -u
printf '\nHeronPanel portable host check\n\n'
for c in node java ttyd unzip zip; do
  if command -v "$c" >/dev/null 2>&1; then
    printf '  %-8s OK\n' "$c"
  else
    printf '  %-8s missing\n' "$c"
  fi
done
printf '\nRequired: Node.js 18.17+ and Java 21+ for current Paper versions.\n'
printf 'Docker and systemd are NOT required by HeronPanel.\n'
