import { createServer } from 'http';
import net from 'net';
import { execFileSync } from 'child_process';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, unlinkSync, rmdirSync, statSync, createReadStream } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join, basename, resolve } from 'path';
import { detectRuntime, getEnvironmentLabel } from './lib/environment.mjs';
import { downloadPaperJar, fetchPaperVersions, ensureServerFiles, writeServerProperties } from './lib/provision.mjs';
import { startServer, stopServer, sendCommand, isRunning, getProcessSnapshot, stopAllServers } from './lib/process-manager.mjs';
import { ensurePasswordHash, verifyPassword, hashNewPassword, createSession, getSessionUserId, destroySession, checkLoginRateLimit, clearLoginFailures } from './lib/auth.mjs';
import { readFileContent, listZipEntries, createZipArchive, collectFilesRecursive, saveUploadedFiles, safeResolve } from './lib/file-utils.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = Number(process.env.PORT || 6767);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = join(__dirname, 'data');
const SERVERS_DIR = join(__dirname, 'servers');
const USERS_DIR = join(SERVERS_DIR, 'users');
const BACKUPS_DIR = join(DATA_DIR, 'backups');
const STATE_FILE = join(DATA_DIR, 'panel-state.json');
const PORT_START = Number(process.env.MC_PORT_START || 25565);
const MAX_BODY = 25 * 1024 * 1024;

[DATA_DIR, SERVERS_DIR, USERS_DIR, BACKUPS_DIR].forEach((dir) => {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
});

const mimeTypes = {
  '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.gif': 'image/gif', '.svg': 'image/svg+xml', '.mp4': 'video/mp4', '.ico': 'image/x-icon',
  '.zip': 'application/zip'
};

function getMimeType(filePath) {
  return mimeTypes[filePath.substring(filePath.lastIndexOf('.')).toLowerCase()] || 'application/octet-stream';
}

function serveStaticFile(res, filePath) {
  try {
    const fullPath = safeResolve(__dirname, filePath);
    if (!existsSync(fullPath)) {
      sendJsonResponse(res, 404, { ok: false, error: 'File not found' });
      return;
    }
    const content = readFileSync(fullPath);
    res.writeHead(200, { 'Content-Type': getMimeType(filePath), 'Content-Length': content.length });
    res.end(content);
  } catch (error) {
    sendJsonResponse(res, 500, { ok: false, error: error.message });
  }
}

function serveDownload(res, filePath, filename) {
  if (!existsSync(filePath)) {
    sendJsonResponse(res, 404, { ok: false, error: 'File not found' });
    return;
  }
  res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Access-Control-Allow-Origin': '*'
  });
  createReadStream(filePath).pipe(res);
}

const defaultState = {
  settings: {
    panelName: 'HeronPanel',
    serverCost: 100,
    maxServers: 5,
    clickTarget: 100,
    clickReward: 10,
    motd: 'Welcome to our Minecraft Server!',
    theme: 'nebula',
    defaultRam: 2,
    defaultCpu: 100,
    defaultDisk: 10,
    local: true,
    pterodactyl: false,
    codesandbox: true,
    github: true,
    vps: true,
    providers: { local: true, pterodactyl: false, codesandbox: true, github: true, vps: true },
    ui: {
      compactMode: false,
      animations: true,
      fontSize: 'medium',
      accentIntensity: 'normal',
      sidebarStyle: 'default',
      consoleTheme: 'dark',
      blurBackground: true
    },
    features: {
      advancedConsole: true, realTimeStats: true, autoBackups: true,
      pluginMarketplace: true, customThemes: true, webTerminal: true,
      localSupport: true, dockerSupport: false, systemdSupport: false, ttydSupport: true,
      serverDownload: true, playerManagement: true, scheduleTasks: true,
      subuserAccess: true, databaseManager: true, networkAllocation: true,
      modInstaller: true, worldEditor: true, apiAccess: true
    },
    sessionTimeout: 60,
    maxLoginAttempts: 5,
    requireEmailVerification: false,
    enableTwoFactor: false,
    consoleLineLimit: 500,
    fileUploadLimit: 100,
    registrationEnabled: true,
    allowUserServerCreation: true,
    userStorageRoot: 'servers/users',
    adminCustomization: {
      dashboardWidgets: true, sidebarSections: true, branding: true, colors: true, typography: true,
      cards: true, buttons: true, statusStyles: true, loginScreen: true, console: true, fileManager: true,
      navigation: true, notifications: true, serverCards: true, tables: true, modals: true, forms: true,
      resourceMeters: true, charts: true, backgrounds: true, glassmorphism: true, animations: true,
      featureFlags: true, roleMatrix: true, quotas: true, nodeLabels: true, locationLabels: true
    }
  },
  coins: 1000,
  clickProgress: 0,
  users: [],
  servers: [],
  activity: [],
  players: [],
  pluginCatalog: [],
  modCatalog: [],
  selectedServerId: null,
  runtime: null
};

function normalizeState(state) {
  state.settings = { ...defaultState.settings, ...state.settings };
  state.settings.features = { ...defaultState.settings.features, ...state.settings.features };
  state.settings.ui = { ...defaultState.settings.ui, ...state.settings.ui };
  state.settings.adminCustomization = { ...defaultState.settings.adminCustomization, ...(state.settings.adminCustomization || {}) };
  state.settings.providers = state.settings.providers || {
    local: state.settings.local !== false,
    pterodactyl: !!state.settings.pterodactyl,
    codesandbox: state.settings.codesandbox !== false,
    github: state.settings.github !== false,
    vps: state.settings.vps !== false
  };
  state.players = state.players || [];
  state.pluginCatalog = state.pluginCatalog || [];
  state.modCatalog = state.modCatalog || [];
  state.activity = state.activity || [];
  state.servers = state.servers || [];
  for (const user of state.users || []) {
    if (user.password) ensurePasswordHash(user);
  }
  if (!(state.users || []).length) {
    // No hard-coded credential is created. First run uses the setup endpoint below.
  }
  for (const server of state.servers) {
    server.ownerId ||= state.users[0]?.id || null;
    server.logLimit ||= 1500;
    server.autoRestart = Boolean(server.autoRestart);
    server.restartDelay = Number(server.restartDelay || 5);
    server.maxRestartAttempts = Number(server.maxRestartAttempts || 3);
    server.crashRecovery ||= { attempts: [], paused: false };
    server.schedules ||= []; server.backups ||= []; server.databases ||= []; server.subusers ||= [];
    server.settings ||= {}; server.startup ||= { variables: {} }; server.startup.variables ||= {};
  }
  return state;
}

function loadState() {
  try {
    if (existsSync(STATE_FILE)) {
      return normalizeState(JSON.parse(readFileSync(STATE_FILE, 'utf8')));
    }
  } catch {
    console.log('Creating new state file');
  }
  return normalizeState(structuredClone(defaultState));
}

function saveState(state) {
  writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

const PANEL_LOCK = join(DATA_DIR, 'panel.lock');
function acquirePanelLock() {
  try {
    if (existsSync(PANEL_LOCK)) {
      const raw = readFileSync(PANEL_LOCK, 'utf8').trim();
      const pid = Number(raw);
      if (pid && pid !== process.pid) {
        try { process.kill(pid, 0); throw new Error(`Another Heron Panel process is already running (PID ${pid}).`); } catch (e) { if (e.code === 'ESRCH') { unlinkSync(PANEL_LOCK); } else throw e; }
      } else unlinkSync(PANEL_LOCK);
    }
    writeFileSync(PANEL_LOCK, String(process.pid), { flag: 'wx' });
  } catch (e) {
    throw new Error(`Panel instance lock failed: ${e.message}`);
  }
}
acquirePanelLock();

let currentState = loadState();
currentState.runtime = detectRuntime();
currentState.runtime.label = getEnvironmentLabel(currentState.runtime);
currentState.settings.theme = 'nebula';
currentState.settings.features.dockerSupport = currentState.runtime.docker;
currentState.settings.features.systemdSupport = currentState.runtime.systemd;
currentState.settings.features.ttydSupport = currentState.runtime.ttyd;
currentState.settings.providers.docker = currentState.runtime.docker;
currentState.settings.providers.local = true;
saveState(currentState);

function sendJsonResponse(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
}

function getUser(token) {
  const userId = getSessionUserId(token);
  return userId ? currentState.users.find((u) => u.id === userId) : null;
}

function publicUser(user) {
  if (!user) return null;
  const { password, passwordHash, ...safe } = user;
  return safe;
}

function sanitizeServer(server) {
  const clone = structuredClone(server);
  if (clone.startup?.variables) {
    for (const key of Object.keys(clone.startup.variables)) if (/pass|token|secret|key/i.test(key)) clone.startup.variables[key] = '••••••••';
  }
  if (clone.docker?.env) { for (const key of Object.keys(clone.docker.env)) if (/pass|token|secret|key/i.test(key)) clone.docker.env[key] = '••••••••'; }
  delete clone._serverDir;
  return clone;
}
function sanitizeStateForUser(user) {
  const admin = user?.role === 'admin';
  return {
    ...currentState,
    users: (currentState.users || []).filter((u) => admin || u.id === user.id).map(publicUser),
    servers: (currentState.servers || []).filter((s) => admin || s.ownerId === user.id).map(sanitizeServer),
    players: (currentState.players || []).filter((p) => admin || currentState.servers.some((s) => s.id === p.serverId && s.ownerId === user.id))
  };
}

function requireAuth(res, token) {
  const user = getUser(token);
  if (!user) {
    sendJsonResponse(res, 401, { ok: false, error: 'Session expired or invalid. Please log in again.' });
    return null;
  }
  return user;
}

function requireServerAccess(res, user, server, permission = 'server.read') {
  if (!user || !server) return false;
  if (user.role === 'admin' || server.ownerId === user.id) return true;
  const found = (server.subusers || []).find((u) => u.userId === user.id || u.email === user.email);
  const perms = String(found?.permissions || '').split(/[,\s]+/).filter(Boolean).map((p) => p.toLowerCase().replaceAll('.', '.'));
  if (found && (perms.includes(permission) || perms.includes('*'))) return true;
  sendJsonResponse(res, 403, { ok: false, error: `Permission denied: ${permission}` });
  return false;
}

function requireAdmin(res, token) {
  const user = requireAuth(res, token);
  if (!user) return null;
  if (user.role !== 'admin') { sendJsonResponse(res, 403, { ok: false, error: 'Administrator permission required.' }); return null; }
  return user;
}

function getServer(id) {
  return currentState.servers.find((s) => s.id === id);
}

function serverDir(id) {
  if (!/^[a-zA-Z0-9_-]+$/.test(String(id))) throw new Error('Invalid server id');
  const server = currentState?.servers?.find((s) => String(s.id) === String(id));
  if (server?.ownerId) {
    const owner = String(server.ownerId);
    if (!/^[a-zA-Z0-9_-]+$/.test(owner)) throw new Error('Invalid owner id');
    const scoped = join(USERS_DIR, owner, 'servers', String(id));
    if (existsSync(scoped) || server.storagePath === scoped) return scoped;
  }
  const legacy = join(SERVERS_DIR, id);
  return legacy;
}

function userRoot(userId) {
  const safe = String(userId || '');
  if (!/^[a-zA-Z0-9_-]+$/.test(safe)) throw new Error('Invalid user id');
  return join(USERS_DIR, safe);
}

function ensureUserStorage(userId) {
  const root = userRoot(userId);
  mkdirSync(join(root, 'servers'), { recursive: true });
  mkdirSync(join(root, 'backups'), { recursive: true });
  mkdirSync(join(root, 'metadata'), { recursive: true });
  return root;
}

async function isTcpPortFree(port) {
  return await new Promise((resolvePort) => {
    const tester = net.createServer();
    tester.once('error', () => resolvePort(false));
    tester.once('listening', () => tester.close(() => resolvePort(true)));
    tester.listen({ host: '127.0.0.1', port });
  });
}

async function allocatePort() {
  const allocated = new Set(currentState.servers.map(s => Number(String(s.allocation || '').split(':').pop())).filter(Boolean));
  for (let port = PORT_START; port < PORT_START + 10000; port++) {
    if (allocated.has(port)) continue;
    if (await isTcpPortFree(port)) return port;
  }
  throw new Error('No free Minecraft allocation found.');
}

function addActivity(msg) {
  currentState.activity.unshift(msg);
  if (currentState.activity.length > 100) currentState.activity.pop();
}

function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'GET' && !url.pathname.startsWith('/api/')) {
    serveStaticFile(res, url.pathname === '/' ? '/index.html' : url.pathname);
    return;
  }
  let body = '';
  req.on('data', (chunk) => {
    if (body.length > MAX_BODY) return;
    body += chunk.toString();
  });
  req.on('end', () => {
    try {
      if (body.length > MAX_BODY) return sendJsonResponse(res, 413, { ok: false, error: 'Request body too large' });
      handleApiRequest(req, res, req.method, url.pathname, body ? JSON.parse(body) : {}, url);
    } catch (error) {
      sendJsonResponse(res, 400, { ok: false, error: error.message || 'Invalid JSON' });
    }
  });
}

function handleApiRequest(req, res, method, path, body, url) {
  if (method === 'OPTIONS') return sendJsonResponse(res, 200, { ok: true });

  const token = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.slice(7) : null;

  const routes = [
    ['POST', '/api/login', () => handleLogin(res, body)],
    ['POST', '/api/setup', () => handleSetup(res, body)],
    ['GET', '/api/admin/overview', () => handleAdminOverview(res, token)],
    ['GET', '/api/admin/diagnostics', () => handleAdminDiagnostics(res, token)],
    ['GET', '/api/admin/process/status', () => handleProcessStatus(res, token)],
    ['GET', '/api/admin/process/health', () => handleProcessHealth(res, token)],
    ['POST', '/api/admin/process/restart', () => handlePanelRestart(res, token)],
    ['POST', '/api/admin/process/startup', () => handlePanelStartupConfig(res, body, token)],
    ['GET', '/api/admin/process/logs', () => handlePanelLogs(res, token)],
    ['POST', '/api/admin/users', () => handleAdminUsers(res, body, token)],
    ['POST', '/api/auth/login', () => handleLogin(res, body)],
    ['POST', '/api/register', () => handleRegister(res, body)],
    ['POST', '/api/auth/register', () => handleRegister(res, body)],
    ['POST', '/api/auth/logout', () => { destroySession(token); sendJsonResponse(res, 200, { ok: true }); }],
    ['GET', '/api/state', () => handleGetState(res, token)],
    ['GET', '/api/runtime', () => sendJsonResponse(res, 200, { ok: true, runtime: detectRuntime() })],
    ['GET', '/api/admin/jobs', () => handleAdminJobs(res, token)],
    ['GET', '/api/admin/servers', () => handleAdminServers(res, token)],
    ['GET', '/api/admin/nodes', () => handleAdminNodes(res, token)],
    ['GET', '/api/admin/locations', () => handleAdminLocations(res, token)],
    ['GET', '/api/admin/allocations', () => handleAdminAllocations(res, token)],
    ['GET', '/api/admin/settings/full', () => handleAdminFullSettings(res, token)],
    ['POST', '/api/admin/customization', () => handleAdminCustomization(res, body, token)],
    ['GET', '/api/admin/user-folders', () => handleAdminUserFolders(res, token)],
    ['GET', '/api/health', () => sendJsonResponse(res, 200, { ok: true, version: '4.0.0', uptime: process.uptime(), runtime: detectRuntime(), serverRoot: SERVERS_DIR })],
    ['POST', '/api/admin/settings', () => handleAdminSettings(res, body, token)],
    ['POST', '/api/account', () => handleAccount(res, body, token)],
    ['POST', '/api/account/settings', () => handleAccount(res, body, token)],
    ['POST', '/api/click', () => handleClick(res, token)],
    ['POST', '/api/broadcast', () => handleBroadcast(res, body, token)],
    ['POST', '/api/marketplace/buy-server-limit', () => handleBuyServerLimit(res, token)],
    ['POST', '/api/marketplace/server-limit', () => handleBuyServerLimit(res, token)],
    ['GET', '/api/paper/versions', () => handlePaperVersions(res)],
    ['GET', '/api/catalog/search', () => handleCatalogSearch(res, url.searchParams)],
    ['POST', '/api/servers', () => handleCreateServer(res, body, token)],
  ];

  for (const [m, p, fn] of routes) {
    if (method === m && path === p) return fn();
  }

  const serverMatch = path.match(/^\/api\/servers\/([^/]+)(\/.*)?$/);
  if (serverMatch) {
    const id = serverMatch[1];
    const sub = serverMatch[2] || '';
    return handleServerRoute(res, method, id, sub, body, url, token);
  }

  const playerMatch = path.match(/^\/api\/players\/([^/]+)\/action$/);
  if (playerMatch && method === 'POST') {
    return handlePlayerAction(res, playerMatch[1], body, token);
  }

  sendJsonResponse(res, 404, { ok: false, error: 'Not found' });
}

function handleServerRoute(res, method, id, sub, body, url, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  const server = getServer(id);
  if (!server && sub !== '') return sendJsonResponse(res, 404, { ok: false, error: 'Server not found' });
  if (server && !requireServerAccess(res, user, server, sub === '/power' ? 'server.power' : sub === '/command' || sub === '/console' ? 'server.console' : 'server.read')) return;
  if (sub === '' && method === 'DELETE' && user.role !== 'admin' && server?.ownerId !== user.id) return sendJsonResponse(res, 403, { ok: false, error: 'Only the owner or an administrator can delete a server.' });
  const dir = serverDir(id);

  if (sub === '' && method === 'DELETE') return handleDeleteServer(res, id);
  if (sub === '/power' && method === 'POST') return handleServerPower(res, server, body);
  if ((sub === '/console' || sub === '/command') && method === 'POST') return handleServerConsole(res, server, body);
  if (sub === '/files' && method === 'GET') return handleGetFiles(res, server, url.searchParams, dir);
  if (sub === '/files' && method === 'POST') return handleFileOperation(res, server, body, dir);
  if (sub === '/file' && method === 'GET') return handleReadFile(res, server, url.searchParams, dir);
  if (sub === '/file' && method === 'POST') return handleSaveFile(res, server, body, dir);
  if (sub === '/file/delete' && method === 'POST') return handleDeleteFile(res, server, body, dir);
  if (sub === '/folder' && method === 'POST') return handleCreateFolder(res, server, body, dir);
  if (sub === '/upload' && method === 'POST') return handleUpload(res, server, body, dir);
  if (sub === '/metrics' && method === 'GET') return handleServerMetrics(res, server);
  if (sub === '/settings' && method === 'POST') return handleServerSettings(res, server, body, dir);
  if (sub === '/identity' && method === 'POST') return handleServerIdentity(res, server, body, dir);
  if (sub === '/icon' && method === 'POST') return handleServerIcon(res, server, body, dir);
  if (sub === '/environment' && method === 'POST') return handleServerEnvironment(res, server, body);
  if (sub === '/backup' && method === 'POST') return handleBackup(res, server, dir, body.action || 'create', body.backupId || null);
  if (sub === '/network' && method === 'POST') return handleNetwork(res, server, body);
  if (sub === '/databases' && method === 'POST') return handleDatabase(res, server, body);
  if (sub === '/schedules' && method === 'POST') return handleSchedule(res, server, body);
  if (sub === '/startup' && method === 'POST') return handleStartup(res, server, body);
  if (sub === '/subusers' && method === 'POST') return handleSubuser(res, server, body);
  if (sub === '/players' && method === 'POST') return handleAddPlayer(res, server, body, dir);
  if (sub === '/install' && method === 'POST') return handleInstall(res, server, body, dir);
  if (sub === '/install-external' && method === 'POST') return handleInstallExternal(res, server, body, dir);
  if (sub === '/install-plugin' && method === 'POST') return handleInstallExternal(res, server, body, dir);
  if (sub === '/remove' && method === 'POST') return handleRemoveResource(res, server, body, dir);
  if (sub === '/zip' && method === 'GET') return handleZipList(res, server, url.searchParams, dir);
  if (sub === '/zip/file' && method === 'GET') return handleZipFile(res, server, url.searchParams, dir);
  if (sub === '/zip/extract' && method === 'POST') return handleZipExtract(res, server, body, dir);
  if (sub === '/download' && method === 'GET') return handleServerDownload(res, server, url.searchParams, dir);

  sendJsonResponse(res, 404, { ok: false, error: 'Not found' });
}

function handleLogin(res, body) {
  const identifier = String(body.identifier || '').trim();
  const maxAttempts = Number(currentState.settings.maxLoginAttempts || 5);
  if (!checkLoginRateLimit(identifier, maxAttempts)) return sendJsonResponse(res, 429, { ok: false, error: 'Too many login attempts. Try again shortly.' });
  const user = currentState.users.find((u) => u.username === identifier || u.email === identifier);
  if (!user || !verifyPassword(body.password || '', user.password)) return sendJsonResponse(res, 401, { ok: false, error: 'Invalid credentials' });
  clearLoginFailures(identifier);
  const token = createSession(user.id, currentState.settings.sessionTimeout);
  user.lastLoginAt = new Date().toISOString();
  user.loginHistory = user.loginHistory || [];
  user.loginHistory.unshift({ at: user.lastLoginAt, ip: null });
  user.loginHistory = user.loginHistory.slice(0, 50);
  addActivity(`Login: ${user.username}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, token, user: publicUser(user) });
}

function handleSetup(res, body) {
  if ((currentState.users || []).length) return sendJsonResponse(res, 409, { ok: false, error: 'Initial setup has already been completed.' });
  const username = String(body.username || '').trim();
  const email = String(body.email || '').trim();
  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(username)) return sendJsonResponse(res, 400, { ok: false, error: 'Username must be 3-32 letters, numbers, _ or -.' });
  if (!email.includes('@')) return sendJsonResponse(res, 400, { ok: false, error: 'A valid email is required.' });
  const adminPassword = hashNewPassword(body.password || '');
  const user = { id: `u_${Date.now()}`, username, email, password: adminPassword, role: 'admin', createdAt: new Date().toISOString() };
  currentState.users.push(user);
  ensureUserStorage(user.id);
  addActivity('Initial administrator account created');
  saveState(currentState);
  const token = createSession(user.id, currentState.settings.sessionTimeout);
  sendJsonResponse(res, 200, { ok: true, token, user: publicUser(user) });
}

function handleRegister(res, body) {
  const { username, email } = body;
  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(String(username || ''))) return sendJsonResponse(res, 400, { ok: false, error: 'Invalid username.' });
  if (String(body.password || '').length < 8) return sendJsonResponse(res, 400, { ok: false, error: 'Password must be at least 8 characters.' });
  if (currentState.users.find((u) => u.username === username || u.email === email)) return sendJsonResponse(res, 400, { ok: false, error: 'User already exists' });
  const newUser = { id: `u_${Date.now()}`, username, email, password: hashNewPassword(body.password), role: 'user', createdAt: new Date().toISOString() };
  currentState.users.push(newUser);
  ensureUserStorage(newUser.id);
  saveState(currentState);
  const token = createSession(newUser.id, currentState.settings.sessionTimeout);
  sendJsonResponse(res, 200, { ok: true, token, user: publicUser(newUser) });
}

function handleGetState(res, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  currentState.runtime = { ...detectRuntime(), label: getEnvironmentLabel(detectRuntime()) };
  sendJsonResponse(res, 200, { ok: true, state: sanitizeStateForUser(user), user: publicUser(user) });
}

function handleAdminSettings(res, body, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  currentState.settings = normalizeState({ settings: { ...currentState.settings, ...body } }).settings;
  saveState(currentState);
  addActivity(`Admin updated panel settings (${user.username})`);
  sendJsonResponse(res, 200, { ok: true, state: sanitizeStateForUser(user) });
}

function handleAccount(res, body, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  const idx = currentState.users.findIndex((u) => u.id === user.id);
  if (body.currentPassword && !verifyPassword(body.currentPassword, currentState.users[idx].password)) return sendJsonResponse(res, 400, { ok: false, error: 'Current password incorrect' });
  if (body.username) currentState.users[idx].username = String(body.username).trim().slice(0, 32);
  if (body.email) currentState.users[idx].email = String(body.email).trim().slice(0, 120);
  if (body.newPassword) currentState.users[idx].password = hashNewPassword(body.newPassword);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, user: publicUser(currentState.users[idx]) });
}

function handleAdminOverview(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const runtime = detectRuntime();
  const servers = currentState.servers;
  for (const u of currentState.users) ensureUserStorage(u.id);
  sendJsonResponse(res, 200, { ok: true, overview: { totalUsers: currentState.users.length, activeUsers: currentState.users.filter((u) => u.lastLoginAt && Date.now() - Date.parse(u.lastLoginAt) < 86_400_000).length, totalServers: servers.length, onlineServers: servers.filter((s) => s.status === 'online').length, offlineServers: servers.filter((s) => s.status !== 'online').length, totalRAM: servers.reduce((n, s) => n + Number(s.ram || 0), 0), totalCPU: servers.reduce((n, s) => n + Number(s.cpu || 0), 0), activePlayers: servers.reduce((n, s) => n + Number(s.playerStats?.current || 0), 0), runtime, processes: servers.map((s) => ({ id: s.id, name: s.name, ownerId: s.ownerId, status: s.status, ...getProcessSnapshot(s.id) })) } });
}

function handleAdminJobs(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const jobs = [];
  for (const server of currentState.servers) {
    for (const backup of (server.backups || [])) jobs.push({ id: `backup-${server.id}-${backup.id}`, type: 'backup', server: server.name, progress: 100, status: 'Completed', started: backup.date, finished: backup.date, error: null });
    if (server.provisionStatus === 'downloading') jobs.push({ id: `install-${server.id}`, type: 'server-install', server: server.name, progress: 0, status: 'Running', started: server.createdAt, finished: null, error: null });
  }
  sendJsonResponse(res, 200, { ok: true, jobs });
}

function handleAdminDiagnostics(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const r = detectRuntime();
  const checks = [
    ['Node.js', r.node, r.node ? r.nodeVersion : 'Unavailable'], ['Java', r.java, r.javaVersion || 'Unavailable'], ['Docker', r.docker, r.docker ? 'Available' : 'Unavailable'], ['systemd', r.systemd, r.systemd ? 'Available' : 'Unavailable'], ['Local Process', Boolean(r.capabilities.childProcess), r.capabilities.childProcess ? 'Available' : 'Unavailable'], ['ttyd', r.ttyd, r.ttyd ? 'Available' : 'Unavailable'], ['Filesystem', r.capabilities.persistentDisk, r.capabilities.persistentDisk ? 'Writable' : 'Permission unavailable'], ['RAM', true, `${r.freeMemoryMB} MB free / ${r.totalMemoryMB} MB`], ['CPU', true, `${r.cpuCount} cores`], ['Network', true, `${r.networkInterfaces} interfaces`]
  ];
  sendJsonResponse(res, 200, { ok: true, diagnostics: checks.map(([name, ok, detail]) => ({ name, ok, detail })), recommendedBackend: r.recommendedBackend });
}

function handleAdminServers(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  sendJsonResponse(res, 200, { ok: true, servers: currentState.servers.map((s) => ({
    id: s.id, name: s.name, ownerId: s.ownerId, owner: currentState.users.find((u) => u.id === s.ownerId)?.username || 'Unknown',
    status: s.status, provider: s.provider, backend: s.backendRequested, allocation: s.allocation, storagePath: s.storagePath || serverDir(s.id)
  })) });
}

function handleAdminNodes(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const r = detectRuntime();
  sendJsonResponse(res, 200, { ok: true, nodes: [{ id: 'local', name: 'Local Node', hostname: r.hostname, os: r.platform, cpu: r.cpuCount, ramMB: r.totalMemoryMB, diskMB: r.diskFreeMB ?? null, java: r.javaVersion || null, docker: !!r.docker, systemd: !!r.systemd, localProcess: true, status: 'healthy', lastHeartbeat: new Date().toISOString() }] });
}

function handleAdminLocations(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const grouped = new Map();
  for (const s of currentState.servers) { const key = s.region || 'Auto'; const item = grouped.get(key) || { id: key.toLowerCase().replace(/[^a-z0-9]+/g,'-'), name: key, servers: 0 }; item.servers += 1; grouped.set(key, item); }
  sendJsonResponse(res, 200, { ok: true, locations: Array.from(grouped.values()) });
}

function handleAdminAllocations(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  sendJsonResponse(res, 200, { ok: true, allocations: currentState.servers.map((s) => ({ serverId: s.id, server: s.name, ownerId: s.ownerId, allocation: s.allocation, used: isRunning(s.id) })) });
}

function handleAdminFullSettings(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  sendJsonResponse(res, 200, { ok: true, settings: currentState.settings });
}

function handleAdminCustomization(res, body, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const next = body && typeof body === 'object' ? body : {};
  const blocked = new Set(['password','passwordHash','secret','token','apiKey']);
  const filtered = Object.fromEntries(Object.entries(next).filter(([k]) => !blocked.has(k)));
  currentState.settings.adminCustomization = { ...currentState.settings.adminCustomization, ...filtered };
  if (filtered.panelName) currentState.settings.panelName = String(filtered.panelName).slice(0, 64);
  if (filtered.theme) currentState.settings.theme = String(filtered.theme).slice(0, 40);
  saveState(currentState);
  addActivity(`Admin customization updated by ${user.username}`);
  sendJsonResponse(res, 200, { ok: true, settings: currentState.settings.adminCustomization });
}

function handleAdminUserFolders(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const folders = currentState.users.map((u) => {
    const root = ensureUserStorage(u.id);
    return { userId: u.id, username: u.username, root, servers: currentState.servers.filter((s) => s.ownerId === u.id).map((s) => ({ id: s.id, name: s.name, path: s.storagePath || serverDir(s.id) })) };
  });
  sendJsonResponse(res, 200, { ok: true, folders });
}

function handleProcessStatus(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  sendJsonResponse(res, 200, { ok: true, status: { pid: process.pid, node: process.version, uptimeSeconds: Math.floor(process.uptime()), memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024), servers: currentState.servers.map((s) => ({ id: s.id, name: s.name, status: s.status, ...getProcessSnapshot(s.id) })) } });
}

function handleProcessHealth(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const r = detectRuntime();
  sendJsonResponse(res, 200, { ok: true, health: { node: true, process: true, api: true, database: true, memory: true, http: true, docker: r.docker, systemd: r.systemd, localProcess: true } });
}

function handlePanelRestart(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  addActivity(`Panel restart requested by ${user.username}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, message: 'Panel will restart after this response.' });
  setTimeout(() => { process.exit(0); }, 150);
}

function handlePanelStartupConfig(res, body, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  currentState.settings.processSupervisor = { ...currentState.settings.processSupervisor, autoStart: body.autoStart !== false, restartOnCrash: body.restartOnCrash !== false, restartDelay: Math.max(1, Number(body.restartDelay || 3)), maxRestarts: Math.max(1, Number(body.maxRestarts || 5)), crashWindowSeconds: Math.max(10, Number(body.crashWindowSeconds || 60)) };
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, settings: currentState.settings.processSupervisor });
}

function handlePanelLogs(res, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  sendJsonResponse(res, 200, { ok: true, logs: currentState.activity.slice(0, 200) });
}

function handleAdminUsers(res, body, token) {
  const user = requireAdmin(res, token);
  if (!user) return;
  const action = body.action;
  if (action === 'create') {
    const username = String(body.username || '').trim();
    const email = String(body.email || '').trim();
    if (!username || !email) return sendJsonResponse(res, 400, { ok: false, error: 'Username and email are required.' });
    if (String(body.password || '').length < 8) return sendJsonResponse(res, 400, { ok: false, error: 'A password of at least 8 characters is required.' });
    if (currentState.users.some((u) => u.username === username || u.email === email)) return sendJsonResponse(res, 409, { ok: false, error: 'User already exists.' });
    const created = { id: `u_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`, username, email, password: hashNewPassword(body.password), role: body.role === 'admin' ? 'admin' : 'user', createdAt: new Date().toISOString() };
    currentState.users.push(created);
    ensureUserStorage(created.id);
  }
  if (action === 'delete') {
    if (String(body.userId) === String(user.id)) return sendJsonResponse(res, 400, { ok: false, error: 'You cannot delete your own administrator account.' });
    currentState.users = currentState.users.filter((u) => u.id !== body.userId);
  }
  if (action === 'role') {
    const target = currentState.users.find((u) => u.id === body.userId);
    if (!target) return sendJsonResponse(res, 404, { ok: false, error: 'User not found.' });
    target.role = body.role === 'admin' ? 'admin' : 'user';
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, users: currentState.users.map(publicUser) });
}


function handleClick(res, token) {
  if (!requireAuth(res, token)) return;
  currentState.clickProgress = (currentState.clickProgress || 0) + 1;
  const target = currentState.settings.clickTarget || 100;
  if (currentState.clickProgress >= target) {
    currentState.coins += currentState.settings.clickReward || 10;
    currentState.clickProgress = 0;
    addActivity(`Earned ${currentState.settings.clickReward} coins from clicking!`);
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleBroadcast(res, body, token) {
  if (!requireAuth(res, token)) return;
  addActivity(`Broadcast: ${body.message}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleBuyServerLimit(res, token) {
  if (!requireAuth(res, token)) return;
  if (currentState.coins < 1000) return sendJsonResponse(res, 400, { ok: false, error: 'Not enough coins' });
  currentState.coins -= 1000;
  currentState.settings.maxServers += 1;
  addActivity(`Increased server limit to ${currentState.settings.maxServers}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

async function handlePaperVersions(res) {
  const versions = await fetchPaperVersions();
  sendJsonResponse(res, 200, { ok: true, versions });
}

function handleCatalogSearch(res, params) {
  const query = (params.get('query') || '').toLowerCase();
  const type = params.get('type') || 'plugin';
  const catalog = type === 'mod' ? currentState.modCatalog : currentState.pluginCatalog;
  const defaults = [
    { id: 'essentials', name: 'EssentialsX', author: 'Essentials Team', description: 'Essential commands for servers', downloads: 5000000 },
    { id: 'worldedit', name: 'WorldEdit', author: 'EngineHub', description: 'In-game world editor', downloads: 8000000 },
    { id: 'luckperms', name: 'LuckPerms', author: 'Luck', description: 'Advanced permissions', downloads: 6000000 },
    { id: 'vault', name: 'Vault', author: 'MilkBowl', description: 'Economy API bridge', downloads: 9000000 },
    { id: 'coreprotect', name: 'CoreProtect', author: 'Intelli', description: 'Block logging and rollback', downloads: 4000000 }
  ];
  const pool = catalog.length ? catalog : defaults;
  const results = pool.filter((item) =>
    !query || item.name?.toLowerCase().includes(query) || item.description?.toLowerCase().includes(query)
  ).slice(0, Number(params.get('limit') || 12));
  sendJsonResponse(res, 200, { ok: true, results });
}

async function handleCreateServer(res, body, token) {
  const user = requireAuth(res, token);
  if (!user) return;

  if (user.role !== 'admin' && currentState.servers.length >= currentState.settings.maxServers) {
    return sendJsonResponse(res, 400, { ok: false, error: 'Server limit reached' });
  }
  if (currentState.coins < currentState.settings.serverCost) {
    return sendJsonResponse(res, 400, { ok: false, error: 'Not enough coins' });
  }

  const {
    name, egg, provider, region, runtime, paperVersion,
    ram, cpu, disk, autoStart, environment
  } = body;

  const serverId = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const runtimeInfo = detectRuntime();
  if (provider === 'docker' && !runtimeInfo.docker) return sendJsonResponse(res, 409, { ok: false, error: 'Docker backend requested, but Docker is unavailable in this environment. Select Local Process.' });
  ensureUserStorage(user.id);
  const dir = join(userRoot(user.id), 'servers', serverId);
  mkdirSync(dir, { recursive: true });

  const port = await allocatePort();
  if (runtime === 'ttyd' && !runtimeInfo.ttyd && runtimeInfo.isContainer) { /* ttyd is optional; local process remains the compatible fallback */ }

  const server = {
    id: serverId,
    name,
    egg: egg || 'Minecraft Java Paper',
    ownerId: user.id,
    storagePath: dir,
    provider: provider || 'local',
    region: region || 'Auto',
    runtime: runtime || 'Java 21',
    ram: parseInt(ram, 10) || currentState.settings.defaultRam || 2,
    cpu: parseInt(cpu, 10) || currentState.settings.defaultCpu || 100,
    disk: parseInt(disk, 10) || currentState.settings.defaultDisk || 10,
    allocation: `127.0.0.1:${port}`,
    status: 'provisioning',
    console: [`[HeronPanel] Provisioning server "${name}"...`],
    files: [],
    startup: {
      command: `java -Xms{{SERVER_MEMORY}}G -Xmx{{SERVER_MEMORY}}G -jar server.jar nogui`,
      variables: { MC_VERSION: paperVersion || 'latest', EULA: 'TRUE' }
    },
    environment: { environment: provider === 'docker' ? 'docker' : runtime === 'ttyd' ? 'ttyd' : 'local-java', config: {} },
    runtimeEnv: provider === 'docker' ? 'docker' : runtime === 'ttyd' ? 'ttyd' : 'local-java',
    backendRequested: provider === 'docker' ? 'docker' : runtime === 'ttyd' ? 'ttyd' : 'local-java',
    autoStart: Boolean(autoStart),
    autoRestart: true,
    restartDelay: 5,
    maxRestartAttempts: 3,
    logLimit: 1500,
    databases: [],
    schedules: [],
    subusers: [],
    backups: [],
    downloadHistory: [],
    settings: {
      motd: currentState.settings.motd,
      icon: '',
      whitelist: [],
      ops: [],
      banned: []
    },
    paperVersion: paperVersion || 'latest',
    provisionStatus: 'downloading',
    createdAt: new Date().toISOString()
  };

  currentState.coins -= currentState.settings.serverCost;
  currentState.servers.push(server);
  currentState.selectedServerId = serverId;
  addActivity(`Creating server: ${name}`);
  saveState(currentState);

  sendJsonResponse(res, 200, { ok: true, state: currentState, server });

  try {
    ensureServerFiles(dir, server);
    const result = await downloadPaperJar(dir, paperVersion || 'latest');
    server.console.push(`[HeronPanel] Downloaded Paper ${result.mcVersion} build ${result.buildNum}`);
    server.console.push(`[HeronPanel] Server files ready in servers/${serverId}/`);
    server.provisionStatus = 'ready';
    server.status = 'offline';
    server.paperVersion = result.mcVersion;

    if (autoStart) {
      startServer(server, dir, () => saveState(currentState));
      server.status = 'starting';
      server.console.push('[HeronPanel] Auto-start enabled (portable local Java)');
    }
  } catch (err) {
    server.console.push(`[HeronPanel] Provision warning: ${err.message}`);
    server.console.push('[HeronPanel] Place server.jar manually in servers folder to start');
    server.provisionStatus = 'partial';
    server.status = 'offline';
  }
  saveState(currentState);
}

function handleDeleteServer(res, id) {
  stopServer(id);
  const idx = currentState.servers.findIndex((s) => s.id === id);
  if (idx === -1) return sendJsonResponse(res, 404, { ok: false, error: 'Server not found' });

  const dir = serverDir(id);
  try {
    if (existsSync(dir)) deleteFolderRecursive(dir);
  } catch (e) {
    console.error('Delete error:', e.message);
  }

  const name = currentState.servers[idx].name;
  currentState.servers.splice(idx, 1);
  addActivity(`Deleted server: ${name}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function deleteFolderRecursive(dir) {
  for (const file of readdirSync(dir)) {
    const fp = join(dir, file);
    if (statSync(fp).isDirectory()) deleteFolderRecursive(fp);
    else unlinkSync(fp);
  }
  rmdirSync(dir);
}

function handleServerMetrics(res, server) {
  const snapshot = getProcessSnapshot(server.id);
  const metrics = {
    status: server.status,
    verifiedOnline: server.status === 'online',
    cpuPercent: snapshot.cpuPercent ?? null,
    memoryMB: snapshot.memoryMB ?? null,
    uptimeSeconds: snapshot.uptimeSeconds ?? null,
    pid: snapshot.pid ?? null,
    backend: snapshot.backend || server.runtimeActive || server.runtimeEnv || 'unavailable',
    players: server.playerStats?.current ?? null,
    playerPeak: server.playerStats?.peak ?? null,
    disk: null,
    network: null,
    tps: null
  };
  sendJsonResponse(res, 200, { ok: true, metrics });
}

function handleServerPower(res, server, body) {
  const dir = serverDir(server.id);
  const onUpdate = () => saveState(currentState);

  switch (body.action) {
    case 'start':
      if (isRunning(server.id)) return sendJsonResponse(res, 400, { ok: false, error: 'Already running' });
      try {
        startServer(server, dir, onUpdate);
        addActivity(`Started server: ${server.name}`);
      } catch (e) {
        return sendJsonResponse(res, 500, { ok: false, error: e.message });
      }
      break;
    case 'stop':
      if (!stopServer(server.id)) return sendJsonResponse(res, 409, { ok: false, error: 'Server is not running.' });
      server.status = 'stopping';
      addActivity(`Stopping server: ${server.name}`);
      break;
    case 'restart':
      stopServer(server.id);
      server.status = 'restarting';
      setTimeout(() => {
        try {
          startServer(server, dir, onUpdate);
        } catch (e) {
          server.status = 'offline';
          server.console.push(`[HeronPanel] Restart failed: ${e.message}`);
        }
        saveState(currentState);
      }, 2000);
      addActivity(`Restarted server: ${server.name}`);
      break;
    case 'kill':
      if (!stopServer(server.id, 'SIGKILL')) return sendJsonResponse(res, 409, { ok: false, error: 'Server is not running.' });
      server.status = 'stopping';
      break;
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerConsole(res, server, body) {
  const command = String(body.command || '').trim();
  if (!command || /[\u0000\r\n]/.test(command)) return sendJsonResponse(res, 400, { ok: false, error: 'Invalid console command.' });
  if (!isRunning(server.id)) return sendJsonResponse(res, 409, { ok: false, error: 'Server is not running; command was not queued.' });
  if (!sendCommand(server.id, command)) return sendJsonResponse(res, 500, { ok: false, error: 'Unable to send command to the server process.' });
  server.console = server.console || []; server.console.push(`> ${command}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleGetFiles(res, server, params, dir) {
  const relPath = params.get('path') || '.';
  const target = safeResolve(dir, relPath === '.' ? '' : relPath);
  try {
    const files = readdirSync(target).map((file) => {
      const fp = join(target, file);
      const stats = statSync(fp);
      return {
        name: file,
        path: join(relPath === '.' ? '' : relPath, file).replace(/\\/g, '/').replace(/^\//, '') || file,
        size: stats.size,
        type: stats.isDirectory() ? 'Folder' : 'File',
        modified: stats.mtime
      };
    });
    sendJsonResponse(res, 200, { ok: true, files, path: relPath });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleReadFile(res, server, params, dir) {
  try {
    const path = params.get('path') || '';
    const content = readFileContent(dir, path);
    sendJsonResponse(res, 200, { ok: true, path, content });
  } catch (e) {
    sendJsonResponse(res, 404, { ok: false, error: e.message });
  }
}

function handleSaveFile(res, server, body, dir) {
  try {
    const target = safeResolve(dir, body.path);
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, body.content ?? '');
    sendJsonResponse(res, 200, { ok: true });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleDeleteFile(res, server, body, dir) {
  try {
    const target = safeResolve(dir, body.path);
    if (statSync(target).isDirectory()) deleteFolderRecursive(target);
    else unlinkSync(target);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleCreateFolder(res, server, body, dir) {
  try {
    mkdirSync(safeResolve(dir, body.path), { recursive: true });
    sendJsonResponse(res, 200, { ok: true });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleUpload(res, server, body, dir) {
  try {
    saveUploadedFiles(dir, body.targetPath || '.', body.files || []);
    addActivity(`Uploaded ${body.files?.length || 0} files to ${server.name}`);
    saveState(currentState);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleFileOperation(res, server, body, dir) {
  handleSaveFile(res, server, { path: body.path, content: body.content }, dir);
}

function handleServerSettings(res, server, body, dir) {
  Object.assign(server.settings, body);
  if (body.ram) server.ram = body.ram;
  if (body.cpu) server.cpu = body.cpu;
  if (body.disk) server.disk = body.disk;
  if (body.name) server.name = body.name;
  writeServerProperties(dir, server, body);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerIdentity(res, server, body, dir) {
  if (body.motd) {
    server.settings.motd = body.motd;
    writeServerProperties(dir, server, { motd: body.motd });
  }
  if (body.iconDataUrl || body.iconUrl) {
    if (body.iconDataUrl) {
      const data = body.iconDataUrl.replace(/^data:image\/\w+;base64,/, '');
      writeFileSync(join(dir, 'server-icon.png'), Buffer.from(data, 'base64'));
      server.settings.icon = body.iconDataUrl;
    } else {
      server.settings.icon = String(body.iconUrl).slice(0, 500);
    }
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleServerIcon(res, server, body, dir) {
  handleServerIdentity(res, server, { iconDataUrl: body.icon, motd: server.settings.motd }, dir);
}

function handleServerEnvironment(res, server, body) {
  server.environment = { environment: body.environment, config: body.config || {} };
  server.runtimeEnv = body.environment;
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleBackup(res, server, dir, action = 'create', backupId = null) {
  try {
    if (action === 'create') {
      const backupName = `backup-${server.id}-${Date.now()}.zip`;
      const backupPath = join(BACKUPS_DIR, backupName);
      createZipArchive(dir, backupPath);
      const stats = statSync(backupPath);
      const verified = stats.size > 0 && existsSync(backupPath);
      if (!verified) throw new Error('Backup verification failed.');
      const entry = { id: Date.now().toString(), name: backupName, date: new Date().toISOString(), size: stats.size, verified: true };
      server.backups = server.backups || []; server.backups.unshift(entry);
      addActivity(`Backup created for ${server.name}`);
      saveState(currentState);
      return sendJsonResponse(res, 200, { ok: true, state: currentState, backup: entry });
    }
    if (action === 'restore') {
      const backup = (server.backups || []).find((b) => b.id === backupId);
      if (!backup) return sendJsonResponse(res, 404, { ok: false, error: 'Backup not found.' });
      stopServer(server.id);
      const backupPath = join(BACKUPS_DIR, basename(backup.name));
      if (!existsSync(backupPath)) return sendJsonResponse(res, 404, { ok: false, error: 'Backup archive is missing.' });
      if (process.platform === 'win32') return sendJsonResponse(res, 501, { ok: false, error: 'Restore is unavailable on Windows in this build.' });
      execFileSync('unzip', ['-o', backupPath, '-d', dir], { stdio: 'ignore', timeout: 120000 });
      addActivity(`Restored backup ${backup.name} to ${server.name}`); saveState(currentState);
      return sendJsonResponse(res, 200, { ok: true, state: currentState });
    }
    return sendJsonResponse(res, 400, { ok: false, error: 'Unknown backup action.' });
  } catch (e) { return sendJsonResponse(res, 500, { ok: false, error: e.message }); }
}

function handleNetwork(res, server, body) {
  if (body.port) {
    const port = Number(body.port);
    if (!Number.isInteger(port) || port < 1024 || port > 65535) return sendJsonResponse(res, 400, { ok: false, error: 'Port must be between 1024 and 65535.' });
    const conflict = currentState.servers.some(s => s.id !== server.id && Number(String(s.allocation || '').split(':').pop()) === port);
    if (conflict) return sendJsonResponse(res, 409, { ok: false, error: 'That port is already allocated to another server.' });
    server.allocation = `127.0.0.1:${port}`;
  }
  server.network = { ...server.network, ...body };
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleDatabase(res, server, body) {
  server.databases = server.databases || [];
  server.databases.push({ id: Date.now().toString(), ...body, createdAt: new Date().toISOString() });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleSchedule(res, server, body) {
  const cron = String(body.cron || '').trim();
  if (!/^([*\/0-9,-]+\s+){4}[*\/0-9,-]+$/.test(cron)) return sendJsonResponse(res, 400, { ok: false, error: 'Use a valid 5-field cron expression.' });
  server.schedules = server.schedules || [];
  const allowed = ['start','stop','restart','backup','announce'];
  const action = String(body.action || 'backup').trim();
  if (!allowed.includes(action) && !action.startsWith('command:')) return sendJsonResponse(res, 400, { ok: false, error: 'Unsupported schedule action.' });
  server.schedules.push({ id: Date.now().toString(), name: String(body.name || 'Schedule').slice(0, 80), cron, action, enabled: true, lastRun: null });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleStartup(res, server, body) {
  server.startup = server.startup || { variables: {} }; server.startup.variables ||= {};
  if (body.paperVersion) server.startup.variables.MC_VERSION = String(body.paperVersion).slice(0, 32);
  if (body.image) server.startup.image = String(body.image).slice(0, 200);
  if (body.javaExecutable) {
    const value = String(body.javaExecutable);
    if (!/^(java|javaw|java\.exe|javaw\.exe)$/i.test(value) && !value.includes('/')) return sendJsonResponse(res, 400, { ok: false, error: 'Unsafe Java executable path.' });
    server.startup.javaExecutable = value;
  }
  if (Array.isArray(body.jvmArgs)) server.startup.jvmArgs = body.jvmArgs.slice(0, 32).map((v) => String(v).slice(0, 200));
  if (body.variablesText) {
    for (const line of String(body.variablesText).split('\n').slice(0, 100)) {
      const [k, ...v] = line.split('=');
      if (k && /^[A-Za-z_][A-Za-z0-9_]*$/.test(k.trim())) server.startup.variables[k.trim()] = v.join('=').slice(0, 500);
    }
  }
  if (body.autoRestart !== undefined) server.autoRestart = Boolean(body.autoRestart);
  if (body.restartDelay !== undefined) server.restartDelay = Math.max(1, Math.min(3600, Number(body.restartDelay) || 5));
  if (body.maxRestartAttempts !== undefined) server.maxRestartAttempts = Math.max(1, Math.min(20, Number(body.maxRestartAttempts) || 3));
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleSubuser(res, server, body) {
  server.subusers = server.subusers || [];
  server.subusers.push({ id: Date.now().toString(), ...body });
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleAddPlayer(res, server, body, dir) {
  currentState.players = currentState.players || [];
  const player = { id: Date.now().toString(), serverId: server.id, ...body };
  currentState.players.push(player);
  if (body.whitelisted) {
    const wlPath = join(dir, 'whitelist.json');
    const wl = existsSync(wlPath) ? JSON.parse(readFileSync(wlPath, 'utf8')) : [];
    if (!wl.find((p) => p.name === body.name)) wl.push({ uuid: player.id, name: body.name });
    writeFileSync(wlPath, JSON.stringify(wl, null, 2));
  }
  if (body.role === 'op') {
    const opsPath = join(dir, 'ops.json');
    const ops = existsSync(opsPath) ? JSON.parse(readFileSync(opsPath, 'utf8')) : [];
    if (!ops.find((p) => p.name === body.name)) ops.push({ uuid: player.id, name: body.name, level: 4 });
    writeFileSync(opsPath, JSON.stringify(ops, null, 2));
  }
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handlePlayerAction(res, playerId, body, token) {
  const user = requireAuth(res, token);
  if (!user) return;
  const player = currentState.players.find((p) => p.id === playerId);
  if (!player) return sendJsonResponse(res, 404, { ok: false, error: 'Player not found' });
  const playerServer = getServer(player.serverId);
  if (!playerServer || !requireServerAccess(res, user, playerServer, 'server.players')) return;
  if (body.action === 'ban') player.banned = true;
  if (body.action === 'unban') player.banned = false;
  if (body.action === 'kick') addActivity(`Kicked player ${player.name}`);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

async function handleInstallExternal(res, server, body, dir) {
  const pluginsDir = join(dir, 'plugins');
  mkdirSync(pluginsDir, { recursive: true });
  const name = body.name || body.url?.split('/').pop() || `${body.id || 'plugin'}.jar`;
  try {
    if (body.url) {
      const resp = await fetch(body.url);
      const buf = Buffer.from(await resp.arrayBuffer());
      writeFileSync(join(pluginsDir, name.endsWith('.jar') ? name : `${name}.jar`), buf);
    } else {
      return sendJsonResponse(res, 400, { ok: false, error: 'No verified download URL was provided. Refusing to create a fake plugin JAR.' });
    }
    addActivity(`Installed ${name} on ${server.name}`);
    saveState(currentState);
    sendJsonResponse(res, 200, { ok: true, state: currentState });
  } catch (e) {
    sendJsonResponse(res, 500, { ok: false, error: e.message });
  }
}

function handleInstall(res, server, body, dir) {
  handleInstallExternal(res, server, { id: body.itemId, name: `${body.itemId}.jar` }, dir);
}

function handleRemoveResource(res, server, body, dir) {
  if (body.type === 'schedule') server.schedules = (server.schedules || []).filter((s) => s.id !== body.id);
  if (body.type === 'database') server.databases = (server.databases || []).filter((d) => d.id !== body.id);
  if (body.type === 'subuser') server.subusers = (server.subusers || []).filter((u) => u.id !== body.id);
  if (body.type === 'backup') server.backups = (server.backups || []).filter((b) => b.id !== body.id);
  if (body.type === 'player') currentState.players = (currentState.players || []).filter((p) => p.id !== body.id);
  saveState(currentState);
  sendJsonResponse(res, 200, { ok: true, state: currentState, server });
}

function handleZipList(res, server, params, dir) {
  const zipPath = safeResolve(dir, params.get('path') || '');
  const entries = listZipEntries(zipPath);
  sendJsonResponse(res, 200, { ok: true, path: params.get('path'), dir: params.get('dir') || '', entries });
}

function handleZipFile(res, server, params, dir) {
  sendJsonResponse(res, 200, {
    ok: true,
    entry: params.get('entry'),
    content: `[Preview unavailable for ${params.get('entry')}]`
  });
}

function handleZipExtract(res, server, body, dir) {
  addActivity(`Extract requested for ${body.entry || body.path} on ${server.name}`);
  sendJsonResponse(res, 200, { ok: true, state: currentState });
}

function handleServerDownload(res, server, params, dir) {
  const type = params.get('type') || 'full';
  const tmpZip = join(BACKUPS_DIR, `download-${server.id}-${Date.now()}.zip`);

  try {
    const filter = type === 'world'
      ? (rel) => rel.startsWith('world')
      : type === 'config'
        ? (rel) => /\.(properties|json|yml|yaml|txt)$/i.test(rel)
        : null;

    if (filter) {
      const files = collectFilesRecursive(dir, dir, filter);
      mkdirSync(join(tmpZip, '..'), { recursive: true });
      createZipArchive(dir, tmpZip, filter);
    } else {
      createZipArchive(dir, tmpZip);
    }

    server.downloadHistory = server.downloadHistory || [];
    server.downloadHistory.unshift({
      type,
      date: new Date().toLocaleDateString(),
      size: `${Math.round(statSync(tmpZip).size / 1024 / 1024)} MB`,
      status: 'completed'
    });
    saveState(currentState);

    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${server.name}-${type}.zip"`,
      'Access-Control-Allow-Origin': '*'
    });
    createReadStream(tmpZip).pipe(res);
  } catch (e) {
    sendJsonResponse(res, 200, {
      ok: true,
      message: 'Download ready',
      downloadPath: dir,
      serverName: server.name,
      note: e.message
    });
  }
}

function cronPartMatches(value, actual, min, max) {
  value = String(value).trim();
  if (value === '*') return true;
  for (const token of value.split(',')) {
    if (token.includes('/')) {
      const [base, stepText] = token.split('/'); const step = Math.max(1, Number(stepText));
      const start = base === '*' ? min : Number(base); if (Number.isInteger(start) && actual >= start && actual <= max && (actual - start) % step === 0) return true;
    } else if (token.includes('-')) {
      const [a,b] = token.split('-').map(Number); if (actual >= a && actual <= b) return true;
    } else if (Number(token) === actual) return true;
  }
  return false;
}
function cronMatches(expr, date = new Date()) {
  const p = String(expr).trim().split(/\s+/); if (p.length !== 5) return false;
  const dow = date.getDay(), dom = date.getDate(), mon = date.getMonth() + 1, hour = date.getHours(), min = date.getMinutes();
  return cronPartMatches(p[0], min, 0, 59) && cronPartMatches(p[1], hour, 0, 23) && cronPartMatches(p[2], dom, 1, 31) && cronPartMatches(p[3], mon, 1, 12) && cronPartMatches(p[4], dow, 0, 6);
}
let schedulerRunning = false;
async function runSchedules() {
  if (schedulerRunning) return; schedulerRunning = true;
  try {
    const now = new Date(); const stamp = now.toISOString().slice(0,16);
    for (const server of currentState.servers) {
      for (const task of (server.schedules || [])) {
        if (task.enabled === false || task.lastRun === stamp || !cronMatches(task.cron, now)) continue;
        task.lastRun = stamp;
        try {
          if (task.action === 'start') startServer(server, serverDir(server.id), () => saveState(currentState));
          else if (task.action === 'stop') stopServer(server.id);
          else if (task.action === 'restart') { stopServer(server.id); setTimeout(() => { try { startServer(server, serverDir(server.id), () => saveState(currentState)); } catch (e) { server.console.push(`[Scheduler] Restart failed: ${e.message}`); saveState(currentState); } }, 2000).unref?.(); }
          else if (task.action === 'backup') handleBackup({ writeHead(){}, end(){} }, server, serverDir(server.id), 'create', null);
          else if (task.action === 'announce' || task.action.startsWith('command:')) { const command = task.action === 'announce' ? String(task.message || 'Scheduled announcement') : task.action.slice(8); sendCommand(server.id, command); }
          addActivity(`Scheduled task '${task.name}' executed on ${server.name}`);
        } catch (e) { server.console = server.console || []; server.console.push(`[Scheduler] ${task.name}: ${e.message}`); }
      }
    }
    saveState(currentState);
  } finally { schedulerRunning = false; }
}
const httpServer = createServer(handleRequest);

httpServer.listen(PORT, HOST, () => {
  const rt = detectRuntime();
  console.log(`\n  ╔════════════════════════════════════════════════════╗`);
  console.log(`  ║  HeronPanel — Portable Nebula / Monochrome Edition ║`);
  console.log(`  ╚════════════════════════════════════════════════════╝`);
  console.log(`  URL:       http://127.0.0.1:${PORT}`);
  console.log(`  Bind:      ${HOST}:${PORT}`);
  console.log(`  Servers:   ${SERVERS_DIR}`);
  console.log(`  Runtime:   ${getEnvironmentLabel(rt)} / local Java`);
  console.log(`  Java:      ${rt.java ? 'Yes' : 'No'}`);
  console.log(`  Docker:    ${rt.docker ? 'available' : 'unavailable'} (optional)`);
  console.log(`  Systemd:   ${rt.systemd ? 'available' : 'unavailable'} (optional)`);
  console.log(`  TTYd:      ${rt.ttyd ? 'available for shell hosting' : 'not installed'}`);
  console.log(`  Login:     use the configured administrator account`);
  console.log(`  Note:      Minecraft processes live under this Node process.\n`);

  setInterval(() => { runSchedules().catch(() => {}); }, 30_000).unref?.();

  // Restore servers configured for auto-start after a panel restart.
  setTimeout(() => {
    for (const server of currentState.servers) {
      if (!server.autoStart || server.provisionStatus !== 'ready' || isRunning(server.id)) continue;
      try {
        startServer(server, serverDir(server.id), () => saveState(currentState));
      } catch (e) {
        server.status = 'offline';
        server.console = server.console || [];
        server.console.push(`[HeronPanel] Auto-start failed: ${e.message}`);
      }
    }
    saveState(currentState);
  }, 1200);
});

const shutdown = () => {
  try {
    // Import is intentionally avoided here; server processes receive a normal
    // stop command through the active process manager on application shutdown.
    for (const server of currentState.servers) {
      if (isRunning(server.id)) stopServer(server.id);
    }
  } catch {}
  try { if (existsSync(PANEL_LOCK)) unlinkSync(PANEL_LOCK); } catch {}
  httpServer.close(() => process.exit(0));
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
