# HeronPanel v6 Default Access

Panel port: **6767**

Administrator username: `admin`
Administrator email: `admin@heronpanel.dev`
Administrator password: `Heron@6767!Panel#2026`

Change the administrator password after first login from Account settings.

Pages:
- `login.html` — login only
- `create-account.html` — account registration only
- `index.html` — user dashboard
- `panel.html` — selected server management
- `admin.html` — global administration
- `marketplace.html` — coins and upgrades
