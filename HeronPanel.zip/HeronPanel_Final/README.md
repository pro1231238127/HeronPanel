# HeronPanel 4.0 — Portable Nebula Edition

A Pterodactyl-inspired Minecraft server control panel built from the supplied HeronPanel project.

## Important runtime design

This edition intentionally does **not** require:
- Docker
- systemd
- a Docker daemon
- a systemd service

Minecraft servers run as normal Java child processes owned by `node server.mjs`.

### Requirements
- Node.js 18.17+ (Node 20/22 recommended)
- Java 21+ for current Paper/Minecraft versions
- Internet access when provisioning a new Paper server
- Writable disk space for `data/` and `servers/`

## Start

```bash
npm start
```

The panel binds to `0.0.0.0:6767` by default.

Open:
`http://127.0.0.1:6767`

Initial administrator: create or use the administrator account configured during setup. Passwords are stored as hashes and are never printed by the server.

## VPS

```bash
chmod +x scripts/start-linux.sh
./scripts/start-linux.sh
```

For a different port:

```bash
PORT=8080 HOST=0.0.0.0 node server.mjs
```

Open TCP port 6767 (or your chosen port) in the VPS firewall/security group.

## Docker (optional)

Docker is **not required**, but it's supported as one more portable way to run
the panel — the container just bundles Node.js + Java together.

```bash
docker compose up -d --build
```

or without compose:

```bash
docker build -t heronpanel .
docker run -d --name heronpanel \
  -p 6767:6767 \
  -v heron-data:/app/data \
  -v heron-servers:/app/servers \
  heronpanel
```

Open `http://127.0.0.1:6767`. Mount extra host ports (e.g. `-p 25565:25565`)
for each Minecraft server port you plan to expose. Data and servers persist
in the `heron-data` / `heron-servers` volumes across container restarts.

## CodeSandbox / GitHub Codespaces

Run:

```bash
npm start
```

The app automatically uses the platform `PORT` environment variable when supplied and binds to all interfaces.

**Minecraft caveat:** a panel can load without Java, but a Minecraft server cannot actually start unless the environment provides a compatible Java runtime and permits child processes/network sockets.

## ttyd

ttyd can be used as an optional browser shell around the project:

```bash
ttyd -p 7681 bash
```

Then run the panel from that shell:

```bash
cd HeronPanel
npm start
```

ttyd is not used as the Minecraft process manager; Java is launched directly by Node.

## Included management features

- Login / registration / account settings
- Admin panel settings
- Server creation and deletion
- Automatic Paper provisioning
- Start / stop / restart / kill
- Live console output and commands
- File browser/editor/upload/delete/create-folder
- ZIP listing/preview/extract hooks
- Server downloads/backups
- Server settings, startup variables and allocations
- Network / database / schedule / subuser management
- Player management hooks
- Plugin/mod catalog and installation hooks
- Marketplace/economy UI
- Responsive dashboard
- Supplied `assets/bg.mp4` background retained
- Nebula-inspired dark UI with a black/white monochrome default
- Portable runtime detection

## What is different from real Pterodactyl

This is **Pterodactyl-inspired**, not the Pterodactyl Panel/ Wings stack itself. Real Pterodactyl relies on Wings/container isolation and a different API/data model. This project instead prioritizes portability and direct Java process execution.

That means there is no container isolation or system service supervision. If the Node panel process is terminated, its Minecraft child processes can also be terminated. Use an external process supervisor only if your hosting environment requires persistent service management.

## Data layout

- `servers/<server-id>/` — Minecraft server files
- `data/panel-state.json` — panel state
- `data/backups/` — generated archives
- `assets/bg.mp4` — original supplied background


## Advanced Nebula runtime

Heron Panel now detects the host environment and uses a real Local Process Minecraft backend as its portable baseline. Docker and systemd are optional backends; ttyd/container environments fall back to Local Process when permitted. Administrator diagnostics expose what the current environment can actually support.

Security rules from the supplied Heron PDFs are treated as requirements: no fake production metrics/console/status, backend-side authorization, path isolation, port conflict checks, password hashing, bounded logs, crash-loop protection, and explicit unavailable states.


## HeronPanel v5 access
Default panel port: **6767**.
The packaged state uses the administrator username `admin`, email `admin@heronpanel.dev`, and a newly generated password that should be changed from Account settings after first login.
New users can register from the login screen when registration is enabled.
User server storage uses `servers/users/<user-id>/servers/<server-id>/` for newly created servers; existing legacy server folders are retained as a compatibility fallback.


## v6 page architecture
- `login.html` — authentication only
- `create-account.html` — registration only
- `index.html` — user dashboard, servers, wallet and activity
- `panel.html` — one selected Minecraft server's management tools
- `admin.html` — global platform administration only
- `marketplace.html` — upgrades and coin economy

Each authenticated user receives isolated storage under `servers/users/<user-id>/servers/`. Admin operations remain backend-authorized.
