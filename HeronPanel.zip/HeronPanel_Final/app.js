const tokenKey = "heronpanel-token";

const providerCatalog = [
  { id: "local", name: "Local Process" },
  { id: "docker", name: "Docker (optional)" },
  { id: "pterodactyl", name: "Pterodactyl" },
  { id: "codesandbox", name: "Codesandbox" },
  { id: "github", name: "GitHub" },
  { id: "vps", name: "Real VPS" }
];

const gameEggs = [
  "Minecraft Java Paper",
  "Minecraft Bedrock",
  "Forge Modded",
  "Fabric Modded",
  "Velocity Proxy",
  "Node.js Bot",
  "Python App"
];

let state = null;
let currentUser = null;
let activeTab = "console";
let searchResults = [];
let searchStatus = "Search Paper/Bukkit/Spigot plugins or Fabric/Forge mods.";
let fileBrowser = { path: ".", entries: [] };
let fileEditor = { path: "", content: "", loaded: false };
let zipViewer = { zipPath: "", dir: "", entries: [], previewEntry: "", previewContent: "" };
let paperVersions = [
  { value: "latest", label: "Latest Paper" },
  { value: "1.21.11", label: "Paper 1.21.11" },
  { value: "1.21.10", label: "Paper 1.21.10" },
  { value: "1.21.8", label: "Paper 1.21.8" },
  { value: "1.21.4", label: "Paper 1.21.4" },
  { value: "1.20.6", label: "Paper 1.20.6" },
  { value: "1.20.4", label: "Paper 1.20.4" },
  { value: "1.20.1", label: "Paper 1.20.1" },
  { value: "1.19.4", label: "Paper 1.19.4" },
  { value: "1.19.2", label: "Paper 1.19.2" },
  { value: "1.19", label: "Paper 1.19" }
];
let paperVersionsPromise = null;
let liveMetrics = new Map();
let commandPaletteOpen = false;

const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
const pageMode = document.body.dataset.page || ($("#dashboardContent") ? "dashboard" : "panel");

function icon(name, className = "button-icon") {
  return `<svg class="${className}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><use href="#i-${name}"></use></svg>`;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function checked(value) {
  return value ? "checked" : "";
}

function selected(value, current) {
  return String(value) === String(current) ? "selected" : "";
}

function canUseAdmin() {
  return currentUser?.role === "admin";
}

function serverIcon(server) {
  return server?.icon || "assets/brand-logo.png";
}

function selectedServer() {
  const id = new URLSearchParams(location.search).get("server") || state?.selectedServerId;
  return state?.servers.find((server) => server.id === id) || state?.servers[0] || null;
}

function variablesText(vars) {
  return Object.entries(vars || {}).map(([key, value]) => `${key}=${value}`).join("\n");
}

function selectedPaperVersion(server) {
  return server?.startup?.variables?.MC_VERSION || "latest";
}

function paperVersionOptions(selected = "latest") {
  const hasSelected = paperVersions.some((version) => version.value === selected);
  const options = hasSelected ? paperVersions : [{ value: selected, label: `Paper ${selected}` }, ...paperVersions];
  return options.map((version) => `<option value="${escapeHtml(version.value)}" ${selectedVersion(version.value, selected)}>${escapeHtml(version.label)}</option>`).join("");
}

function selectedVersion(value, current) {
  return String(value) === String(current) ? "selected" : "";
}

function generateDockerCompose(server) {
  const config = server.dockerConfig || generateDockerConfigHelper(server);
  return `version: '3.8'
services:
  minecraft:
    image: ${config.image}
    container_name: ${server.name.toLowerCase().replace(/\s+/g, '-')}
    ports:
      ${Object.entries(config.ports || {}).map(([host, container]) => `      - "${host}:${Object.keys(container)[0]}"`).join('\n')}
    environment:
      ${Object.entries(config.environment || {}).map(([key, value]) => `      - ${key}=${value}`).join('\n')}
    volumes:
      ${Object.entries(config.volumes || {}).map(([host, container]) => `      - ${host}:${container}`).join('\n')}
    restart: unless-stopped
`;
}

function generateDockerConfigHelper(server) {
  return {
    image: `itzg/minecraft-server:${server.startup?.variables?.MC_VERSION || 'latest'}`,
    ports: { '25565:25565': {} },
    environment: {
      EULA: 'TRUE',
      MEMORY: `${server.ram}G`,
      SERVER_NAME: server.name,
      MOTD: server.settings?.motd || 'Welcome'
    },
    volumes: {
      [`./${server.id}`]: '/data'
    }
  };
}

function fillPaperVersionSelect(select) {
  const selected = select.value || select.dataset.selected || "latest";
  select.innerHTML = paperVersionOptions(selected);
  select.value = paperVersions.some((version) => version.value === selected) ? selected : "latest";
}

async function loadPaperVersions() {
  if (paperVersionsPromise) return paperVersionsPromise;
  paperVersionsPromise = api("/api/paper/versions")
    .then((payload) => {
      if (Array.isArray(payload.versions) && payload.versions.length) {
        paperVersions = payload.versions;
        $$(".paper-version-select").forEach(fillPaperVersionSelect);
      }
    })
    .catch(() => {})
    .finally(() => {
      paperVersionsPromise = null;
    });
  return paperVersionsPromise;
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Unable to read icon file"));
    reader.readAsDataURL(file);
  });
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function cleanUiPath(value) {
  const clean = String(value || ".").replaceAll("\\", "/").replace(/^\/+|\/+$/g, "");
  return clean && clean !== "." ? clean : ".";
}

function parentUiPath(value) {
  const clean = cleanUiPath(value);
  if (clean === ".") return ".";
  const parts = clean.split("/").filter(Boolean);
  parts.pop();
  return parts.length ? parts.join("/") : ".";
}

function joinUiPath(base, name) {
  const cleanBase = cleanUiPath(base);
  const cleanName = String(name || "").replaceAll("\\", "/").replace(/^\/+/, "");
  return cleanBase === "." ? cleanName : `${cleanBase}/${cleanName}`;
}

function filesInCurrentFolder(server) {
  const path = cleanUiPath(fileBrowser.path);
  if (fileBrowser.entries.length) return fileBrowser.entries;
  const prefix = path === "." ? "" : `${path}/`;
  const map = new Map();
  for (const file of server.files || []) {
    if (!file.name.startsWith(prefix)) continue;
    const rest = file.name.slice(prefix.length);
    if (!rest) continue;
    const parts = rest.split("/").filter(Boolean);
    if (!parts.length) continue;
    const label = parts[0];
    const isFolder = parts.length > 1 || file.type === "Folder";
    const name = `${prefix}${label}${isFolder ? "/" : ""}`;
    if (!map.has(name)) {
      map.set(name, { ...file, name, label, type: isFolder ? "Folder" : file.type });
    }
  }
  return Array.from(map.values()).sort((a, b) => {
    if (a.type === "Folder" && b.type !== "Folder") return -1;
    if (a.type !== "Folder" && b.type === "Folder") return 1;
    return (a.label || a.name).localeCompare(b.label || b.name);
  });
}

function isZipFile(file) {
  return String(file.name || "").toLowerCase().endsWith(".zip");
}

function setButtonBusy(button, label) {
  if (!button) return () => {};
  const html = button.innerHTML;
  button.disabled = true;
  button.innerHTML = `<span class="button-spinner"></span>${escapeHtml(label)}`;
  return () => {
    button.disabled = false;
    button.innerHTML = html;
  };
}

async function api(path, options = {}) {
  const headers = options.body ? { "content-type": "application/json" } : {};
  const token = localStorage.getItem(tokenKey);
  if (token) headers.authorization = `Bearer ${token}`;
  const response = await fetch(path, {
    method: options.method || "GET",
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    if (response.status === 401) showAuth();
    throw new Error(payload.error || "Request failed");
  }
  if (payload.state) state = payload.state;
  if (payload.user) currentUser = payload.user;
  return payload;
}

function applyTheme() {
  if (!state) return;
  $$("[data-bind='panelName']").forEach((node) => {
    node.textContent = state.settings.panelName;
  });

  const theme = state.settings.theme || 'nebula';
  document.body.setAttribute('data-theme', theme);

  const ui = state.settings.ui || {};
  document.body.classList.toggle('compact-mode', !!ui.compactMode);
  document.body.classList.toggle('no-animations', ui.animations === false);
  document.body.classList.toggle('no-blur', ui.blurBackground === false);
  document.body.classList.remove('font-small', 'font-large');
  if (ui.fontSize === 'small') document.body.classList.add('font-small');
  if (ui.fontSize === 'large') document.body.classList.add('font-large');

  const accountButton = $("#accountSettingsBtn");
  if (accountButton && currentUser) {
    accountButton.title = `Account settings: ${currentUser.username}`;
  }
  const adminButton = $("#adminPanelBtn");
  if (adminButton) {
    adminButton.classList.toggle("hidden", !canUseAdmin());
  }
  const suffix = pageMode === "marketplace" ? "Marketplace" : pageMode === "dashboard" ? "Dashboard" : "Panel";
  document.title = `${state.settings.panelName} ${suffix}`;
}

function showAuth() {
  $("#authScreen").classList.remove("hidden");
  $("#panelShell")?.classList.add("hidden");
  $("#dashboardShell")?.classList.add("hidden");
  $("#marketplaceShell")?.classList.add("hidden");
}

function showPanel() {
  $("#authScreen").classList.add("hidden");
  if (pageMode === "dashboard") {
    $("#dashboardShell")?.classList.remove("hidden");
  } else if (pageMode === "marketplace") {
    $("#marketplaceShell")?.classList.remove("hidden");
  } else {
    $("#panelShell")?.classList.remove("hidden");
  }
}

async function refresh() {
  const payload = await api("/api/state");
  state = payload.state;
  if (payload.user) currentUser = payload.user;
  applyTheme();
  syncAdminNavigation();
  showPanel();
  render();
  const server = selectedServer();
  if (server) await refreshLiveMetrics(server.id);
}

async function refreshLiveMetrics(serverId) {
  try {
    const payload = await api(`/api/servers/${encodeURIComponent(serverId)}/metrics`);
    liveMetrics.set(serverId, payload.metrics);
    if (state && selectedServer()?.id === serverId) updateHeaderMetrics(payload.metrics);
  } catch {}
}

function metricText(value, suffix = "") { return value === null || value === undefined ? "Unavailable" : `${value}${suffix}`; }
function updateHeaderMetrics(metrics) {
  const cpu = metrics?.cpuPercent; const ram = metrics?.memoryMB;
  const cpuEl = document.querySelector('[data-bind="cpuUsage"]'); const ramEl = document.querySelector('[data-bind="ramUsage"]');
  if (cpuEl) cpuEl.textContent = metricText(cpu, "%");
  if (ramEl) ramEl.textContent = metricText(ram, " MB");
  const pill = document.querySelector('#serverStatusPill');
  if (pill) { pill.classList.toggle('online', metrics?.status === 'online'); const label = pill.querySelector('[data-bind="serverStatus"]'); if (label) label.textContent = metrics?.status || 'unknown'; }
}

function openServer(id) {
  if (pageMode !== "panel") {
    location.href = `panel.html?server=${encodeURIComponent(id)}#console`;
    return;
  }
  fileBrowser = { path: ".", entries: [] };
  fileEditor = { path: "", content: "", loaded: false };
  zipViewer = { zipPath: "", dir: "", entries: [], previewEntry: "", previewContent: "" };
  history.pushState(null, "", `panel.html?server=${encodeURIComponent(id)}#${activeTab}`);
  state.selectedServerId = id;
  render();
}

function setTab(tab) {
  activeTab = tab;
  history.replaceState(null, "", `panel.html?server=${encodeURIComponent(selectedServer()?.id || "")}#${tab}`);
  render();
  if (tab.startsWith('admin-')) setTimeout(loadAdminTab, 0);
}

function render() {
  if (!state) return;
  if (pageMode === "dashboard") {
    renderDashboard();
    fillCreateOptions();
    return;
  }
  if (pageMode === "marketplace") {
    renderMarketplace();
    fillCreateOptions();
    return;
  }
  const hashTab = location.hash.replace("#", "");
  if (hashTab) activeTab = hashTab;
  renderServerPicker(false);
  renderTabs();
  renderContent();
  fillCreateOptions();
  if (activeTab.startsWith('admin-')) setTimeout(loadAdminTab, 0);
}

function renderMarketplace() {
  const content = $("#marketplaceContent");
  if (!content) return;
  content.innerHTML = `
    <section class="dashboard-hero marketplace-hero">
      <div>
        <p class="eyebrow">Marketplace</p>
        <h1>Upgrade store</h1>
      </div>
      <div class="dashboard-wallet">
        <span>${icon("coin")}Coins</span>
        <strong>${Number(state.coins || 0).toLocaleString("en-IN")}</strong>
      </div>
    </section>
    <section class="dashboard-section marketplace-section">
      <div class="section-header">
        <div>
          <p class="eyebrow">Server upgrades</p>
          <h2>Limits and capacity</h2>
        </div>
        <span class="status-pill">${state.servers.length}/${state.settings.maxServers} servers</span>
      </div>
      <div class="marketplace-grid">
        <article class="marketplace-card">
          <div class="marketplace-offer">
            <div class="market-icon">${icon("server", "catalog-svg")}</div>
            <div>
              <strong>Server limit upgrade</strong>
              <p class="muted">Spend 1000 coins to increase your max server limit from ${state.settings.maxServers} to ${Number(state.settings.maxServers) + 1}.</p>
            </div>
          </div>
          <div class="marketplace-buy-row">
            <span class="status-pill">${icon("coin")}1000</span>
            <button class="primary-button" data-action="buy-server-limit" type="button" ${Number(state.coins || 0) < 1000 ? "disabled" : ""}>${icon("coin")}Buy upgrade</button>
          </div>
        </article>
      </div>
    </section>
  `;
}

function renderDashboard() {
  const content = $("#dashboardContent");
  if (!content) return;
  const running = state.servers.filter((server) => server.status === "online").length;
  const totalRam = state.servers.reduce((n, s) => n + Number(s.ram || 0), 0);
  const totalCpu = state.servers.reduce((n, s) => n + Number(s.cpu || 0), 0);
  const totalDisk = state.servers.reduce((n, s) => n + Number(s.disk || 0), 0);
  const activePlayers = state.servers.reduce((n, s) => n + Number(s.playerStats?.current || 0), 0);
  const runtime = state.runtime || {};
  content.innerHTML = `
    <section class="dashboard-hero nebula-hero">
      <div>
        <p class="eyebrow">Heron Panel • Nebula Control Center</p>
        <h1>Manage every Minecraft server from one premium dashboard.</h1>
        <p class="muted">${escapeHtml(runtime.label || 'Runtime detection')} • ${escapeHtml(runtime.recommendedBackend || 'local')} backend recommended • real backend metrics only</p>
      </div>
      <div class="dashboard-wallet runtime-badge"><span>${icon("server")}Environment</span><strong>${escapeHtml(runtime.label || "Detected")}</strong></div>
    </section>
    <section class="dashboard-strip">
      ${dashboardStat("Servers", state.servers.length, "server")}
      ${dashboardStat("Online", running, "activity")}
      ${dashboardStat("RAM", `${totalRam} GB`, "server")}
      ${dashboardStat("CPU", `${totalCpu}%`, "activity")}
      ${dashboardStat("Disk", `${totalDisk} GB`, "folder")}
      ${dashboardStat("Players", activePlayers, "users")}
    </section>
    <section class="dashboard-main-grid">
      <article class="panel-card">
        <div class="section-header">
          <div><p class="eyebrow">Your infrastructure</p><h2>Servers</h2></div>
          <button class="primary-button" data-action="open-create" type="button">${icon("plus")}Create Server</button>
        </div>
        <div class="server-list compact-list">
          ${state.servers.map(renderDashboardServer).join("") || `<div class="empty-state compact-empty"><h2>No server yet</h2><p class="muted">Create your first real Minecraft server.</p></div>`}
        </div>
      </article>
      <aside class="dashboard-side">
        <article class="panel-card">
          <div class="section-header compact"><h2>Environment health</h2><button class="mini-button" data-action="open-environment">${icon("server")}Inspect</button></div>
          <div class="health-grid">
            ${healthChip("Local Process", !!runtime.capabilities?.localJava)}
            ${healthChip("Docker", !!runtime.docker)}
            ${healthChip("systemd", !!runtime.systemd)}
            ${healthChip("ttyd", !!runtime.ttyd)}
            ${healthChip("Java", !!runtime.java)}
            ${healthChip("Node.js", !!runtime.node)}
          </div>
        </article>
        <article class="panel-card">
          <div class="section-header compact"><h2>Recent activity</h2></div>
          <div class="activity-feed compact-activity">${(state.activity || []).slice(0, 8).map((item) => `<div class="activity-item">${escapeHtml(item)}</div>`).join("") || `<div class="activity-item">No activity yet.</div>`}</div>
        </article>
      </aside>
    </section>
  `;
}

function healthChip(label, ok) {
  return `<span class="health-chip ${ok ? 'ok' : 'off'}"><i></i>${escapeHtml(label)} <strong>${ok ? 'Ready' : 'Unavailable'}</strong></span>`;
}

function syncAdminNavigation() {
  $$('.admin-only').forEach((el) => el.classList.toggle('hidden', !canUseAdmin()));
  const adminButton = $('#adminPanelBtn'); if (adminButton) adminButton.classList.toggle('hidden', !canUseAdmin());
}
function renderCommandPalette() {
  const input=$('#commandPaletteInput'), results=$('#commandPaletteResults'); if(!input||!results) return;
  const q=input.value.trim().toLowerCase();
  const items=[];
  (state?.servers||[]).forEach(s=>items.push({kind:'Server',label:s.name,meta:`${s.status} • ${s.allocation}`,action:()=>openServer(s.id)}));
  (state?.users||[]).filter(u=>canUseAdmin()).forEach(u=>items.push({kind:'User',label:u.username,meta:u.email||'',action:()=>toast('User',`${u.username} • ${u.role||'user'}`)}));
  const filtered=items.filter(x=>!q||`${x.kind} ${x.label} ${x.meta}`.toLowerCase().includes(q)).slice(0,20);
  results.innerHTML=filtered.map((x,i)=>`<div class="command-result" data-command-index="${i}"><strong>${escapeHtml(x.label)}</strong><span class="muted">${escapeHtml(x.kind)} • ${escapeHtml(x.meta)}</span></div>`).join('')||`<div class="empty-state">No results.</div>`;
  results.querySelectorAll('[data-command-index]').forEach(el=>el.addEventListener('click',()=>{ filtered[Number(el.dataset.commandIndex)].action(); $('#commandPaletteModal').classList.add('hidden'); }));
}
function openCommandPalette(){ const modal=$('#commandPaletteModal'), input=$('#commandPaletteInput'); if(!modal||!input)return; modal.classList.remove('hidden'); input.value=''; renderCommandPalette(); input.focus(); }

function dashboardStat(label, value, iconName) {
  return `
    <article class="dashboard-stat" aria-label="${escapeHtml(label)}">
      <span class="dashboard-stat-icon">${icon(iconName)}</span>
      <span class="dashboard-stat-copy">
        <span>${escapeHtml(label)}</span>
        <strong>${escapeHtml(value)}</strong>
      </span>
    </article>
  `;
}

function renderDashboardServer(server) {
  return `
    <div class="server-row dashboard-server-row">
      <img class="server-icon" src="${escapeHtml(serverIcon(server))}" alt="">
      <div>
        <h3>${escapeHtml(server.name)}</h3>
        <div class="server-meta">
          <span>${escapeHtml(server.egg)}</span>
          <span>${escapeHtml(server.allocation)}</span>
          <span>${escapeHtml(server.status)}</span>
        </div>
      </div>
      <button class="primary-button" type="button" data-action="open-server" data-id="${escapeHtml(server.id)}">${icon("server")}Open</button>
    </div>
  `;
}

function renderTabs() {
  $$(".tab-link").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === activeTab);
  });
}

function renderServerPicker(force = false) {
  const picker = $("#serverPicker");
  if (!force && selectedServer()) {
    picker.classList.add("hidden");
    return;
  }
  picker.classList.remove("hidden");
  picker.innerHTML = `
    <div class="section-header">
      <div>
        <p class="eyebrow">Servers</p>
        <h2>Choose a server to control</h2>
      </div>
      <button class="primary-button" id="pickerCreateBtn" type="button">${icon("plus")}Create server</button>
    </div>
    <div class="server-list">
      ${state.servers.map(renderServerCard).join("") || `<div class="empty-state"><h2>No servers</h2><p class="muted">Create your first server.</p></div>`}
    </div>
  `;
}

function renderServerCard(server) {
  return `
    <div class="server-row">
      <img class="server-icon" src="${escapeHtml(serverIcon(server))}" alt="">
      <div>
        <h3>${escapeHtml(server.name)}</h3>
        <div class="server-meta">
          <span>${escapeHtml(server.egg)}</span>
          <span>${escapeHtml(server.allocation)}</span>
          <span>${escapeHtml(server.status)}</span>
        </div>
      </div>
      <button class="primary-button" type="button" data-action="open-server" data-id="${escapeHtml(server.id)}">${icon("server")}Open</button>
    </div>
  `;
}

function renderContent() {
  const server = selectedServer();
  const content = $("#panelContent");
  if (activeTab.startsWith("admin-")) {
    if (!canUseAdmin()) { content.innerHTML = `<div class="empty-state"><h2>Administrator access required</h2><p class="muted">The backend will reject unauthorized admin APIs.</p></div>`; return; }
    content.innerHTML = renderAdminTab(activeTab);
    return;
  }
  if (!server) {
    content.innerHTML = "";
    renderServerPicker(true);
    return;
  }
  $("#serverPicker").classList.add("hidden");
  const renderers = {
    console: renderConsole,
    files: renderFiles,
    databases: renderDatabases,
    schedules: renderSchedules,
    subusers: renderUsers,
    backups: renderBackups,
    network: renderNetwork,
    startup: renderStartup,
    settings: renderSettings,
    plugins: () => renderInstaller("plugin"),
    mods: () => renderInstaller("mod"),
    players: renderPlayers,
    environment: renderEnvironment,
    download: renderDownload,
    activity: renderActivity
  };
  content.innerHTML = (renderers[activeTab] || renderConsole)(server);
  if (activeTab === 'console') refreshLiveMetrics(server.id);
}

function renderConsole(server) {
  const m = liveMetrics.get(server.id) || {};
  const consoleLines = Array.isArray(server.console) ? server.console.slice(-Math.max(100, Number(state.settings?.consoleLineLimit || 500))) : [];
  return `
    <div class="ptero-console-grid">
      <aside class="ptero-side">
        <article class="ptero-card">
          <div class="ptero-card-head">${icon("server")} ${escapeHtml(server.name)}</div>
          <div class="server-status-line"><span class="dot ${m.status === "online" ? "live" : ""}"></span>${escapeHtml(m.status || server.status || "unknown")}</div>
          <div class="stat-line address-line">${icon("network")} ${escapeHtml(server.allocation || "Unavailable")}</div>
          <div class="stat-line">${icon("code")} ${escapeHtml(server.egg || "Minecraft")}</div>
          <div class="stat-line">${icon("activity")} CPU ${metricText(m.cpuPercent, "%")}</div>
          <div class="stat-line">${icon("server")} RAM ${metricText(m.memoryMB, " MB")}</div>
          <div class="stat-line">${icon("users")} Players ${metricText(m.players)}</div>
          <div class="stat-line">${icon("activity")} Uptime ${m.uptimeSeconds === null || m.uptimeSeconds === undefined ? "Unavailable" : formatUptime(m.uptimeSeconds)}</div>
        </article>
        <article class="ptero-card power-card">
          <button class="ghost-button" data-action="power" data-id="${escapeHtml(server.id)}" data-power="start">${icon("play")}Start</button>
          <button class="ghost-button" data-action="power" data-id="${escapeHtml(server.id)}" data-power="restart">${icon("restart")}Restart</button>
          <button class="danger-button" data-action="power" data-id="${escapeHtml(server.id)}" data-power="stop">${icon("stop")}Stop</button>
        </article>
      </aside>
      <section class="console-main">
        <div class="console-toolbar"><span class="status-pill">${icon("terminal")}Live Console</span><span class="muted">stdout + stderr • bounded log window</span></div>
        <div class="console-box ptero-console" id="liveConsole">
          ${consoleLines.map((line) => `<div class="console-line">${escapeHtml(line)}</div>`).join("") || `<div class="console-line muted">No console output yet.</div>`}
        </div>
        <form class="command-row" data-command-form data-id="${escapeHtml(server.id)}">
          <input name="command" autocomplete="off" placeholder="Enter Minecraft command…">
          <button class="primary-button" type="submit">${icon("send")}Send</button>
        </form>
      </section>
    </div>
    <div class="chart-grid">
      ${chartCard("Live CPU", "%", m.cpuPercent)}
      ${chartCard("Live Memory", " MB", m.memoryMB)}
      ${chartCard("Players", "", m.players)}
    </div>
  `;
}

function formatUptime(seconds) { const s=Number(seconds)||0; const d=Math.floor(s/86400); const h=Math.floor((s%86400)/3600); const m=Math.floor((s%3600)/60); const sec=s%60; return `${d?d+'d ':''}${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`; }

function chartCard(title, unit, value) {
  const unavailable = value === null || value === undefined || Number.isNaN(Number(value));
  const pct = unavailable ? 0 : Math.min(100, Math.max(0, Number(value)));
  return `<article class="chart-card"><div class="ptero-card-head">${icon("activity")} ${title}</div><div class="real-meter"><span style="width:${pct}%"></span></div><small>${unavailable ? "Unavailable" : `${escapeHtml(value)}${unit}`}</small></article>`;
}

function renderAdminTab(tab) {
  if (tab === 'admin-overview') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Admin</p><h1>Overview</h1></div><span class="status-pill">Protected by backend RBAC</span></div><div id="adminOverviewData" class="admin-live-grid"><div class="empty-state"><p class="muted">Loading live overview…</p></div></div></div>`;
  if (tab === 'admin-users') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Admin</p><h1>Users & Roles</h1></div></div><div id="adminUsersData" class="admin-table-card"><div class="empty-state"><p class="muted">Loading users…</p></div></div></div>`;
  if (tab === 'admin-diagnostics') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">System</p><h1>Environment Diagnostics</h1></div></div><div id="adminDiagnosticsData" class="diagnostics-grid"><div class="empty-state"><p class="muted">Checking environment…</p></div></div></div>`;
  if (tab === 'admin-processes') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">System</p><h1>Process Manager</h1></div></div><div id="adminProcessData" class="admin-table-card"><div class="empty-state"><p class="muted">Loading process state…</p></div></div></div>`;
  if (tab === 'admin-jobs') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Operations</p><h1>Job Queue</h1></div></div><div id="adminJobsData" class="admin-table-card"><div class="empty-state"><p class="muted">Loading jobs…</p></div></div></div>`;
  if (tab === 'admin-security') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Security</p><h1>Security Center</h1></div></div><div class="panel-card"><p>Backend-enforced sessions, password hashing, rate limiting, permission checks, audit-ready activity and tenant isolation are active.</p></div></div>`;
  const adminCards = {
    'admin-servers':['Servers','adminServersData'], 'admin-nodes':['Nodes','adminNodesData'], 'admin-locations':['Locations','adminLocationsData'], 'admin-allocations':['Allocations','adminAllocationsData'],
    'admin-software':['Software / Templates','adminSoftwareData'], 'admin-databases':['Databases','adminDatabasesData'], 'admin-backups':['Backups','adminBackupsData'], 'admin-schedules':['Schedules','adminSchedulesData'],
    'admin-activity':['Activity','adminActivityData'], 'admin-logs':['System Logs','adminLogsData'], 'admin-audit':['Audit Logs','adminAuditData'], 'admin-api':['API','adminApiData'], 'admin-webhooks':['Webhooks','adminWebhooksData'],
    'admin-notifications':['Notifications','adminNotificationsData'], 'admin-branding':['Branding','adminBrandingData'], 'admin-maintenance':['Maintenance','adminMaintenanceData'], 'admin-updates':['Updates','adminUpdatesData'], 'admin-health':['System Health','adminHealthData']
  };
  if (adminCards[tab]) { const [title,id] = adminCards[tab]; return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Administration</p><h1>${title}</h1></div><span class="status-pill">Backend connected</span></div><div id="${id}" class="admin-table-card panel-card"><div class="empty-state"><p class="muted">Loading ${title.toLowerCase()}…</p></div></div></div>`; }
  if (tab === 'admin-customize') return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Admin Studio</p><h1>Ultra Customization</h1><p class="muted">Schema-driven controls for the panel shell, dashboards, navigation and visual system.</p></div></div><div class="panel-card"><div id="adminCustomizeData" class="admin-custom-grid"></div><button class="primary-button" id="saveCustomizationBtn" type="button">Save customization</button></div></div>`;
  return `<div class="admin-page"><div class="section-header"><div><p class="eyebrow">Admin</p><h1>System Settings</h1></div></div><div class="panel-card"><p>Use the existing Settings modal for current branding and panel configuration. Runtime-specific availability is shown in Diagnostics.</p></div></div>`;
}

async function loadAdminTab() {
  if (!activeTab.startsWith('admin-') || !canUseAdmin()) return;
  try {
    if (activeTab === 'admin-overview') { const p = await api('/api/admin/overview'); const o=p.overview; $('#adminOverviewData').innerHTML=`${dashboardStat('Users',o.totalUsers,'users')}${dashboardStat('Servers',o.totalServers,'server')}${dashboardStat('Online',o.onlineServers,'activity')}${dashboardStat('RAM',o.totalRAM+' GB','server')}${dashboardStat('CPU',o.totalCPU+'%','activity')}${dashboardStat('Players',o.activePlayers,'users')}`; return; }
    if (activeTab === 'admin-diagnostics') { const p = await api('/api/admin/diagnostics'); $('#adminDiagnosticsData').innerHTML=p.diagnostics.map(x=>`<article class="panel-card diagnostic-card"><strong>${escapeHtml(x.name)}</strong><span class="status-pill ${x.ok?'online':''}">${x.ok?'Ready':'Unavailable'}</span><p class="muted">${escapeHtml(x.detail)}</p></article>`).join(''); return; }
    if (activeTab === 'admin-processes') { const p = await api('/api/admin/process/status'); $('#adminProcessData').innerHTML=`<div class="server-list">${p.status.servers.map(s=>`<div class="server-row"><div><h3>${escapeHtml(s.name)}</h3><p class="muted">PID ${escapeHtml(s.pid ?? 'Unavailable')} • ${escapeHtml(s.backend||'Unavailable')} • CPU ${escapeHtml(s.cpuPercent ?? 'Unavailable')} • RAM ${escapeHtml(s.memoryMB ?? 'Unavailable')} MB</p></div><span class="status-pill">${escapeHtml(s.status)}</span></div>`).join('')||'<div class="empty-state">No managed processes.</div>'}</div>`; return; }
    if (activeTab === 'admin-jobs') { const p=await api('/api/admin/jobs'); $('#adminJobsData').innerHTML=`<div class="server-list">${p.jobs.map(j=>`<div class="server-row"><div><h3>${escapeHtml(j.type)}</h3><p class="muted">${escapeHtml(j.server)} • ${escapeHtml(j.started||'')}</p></div><span class="status-pill">${escapeHtml(j.status)} ${escapeHtml(j.progress)}%</span></div>`).join('')||'<div class="empty-state">No background jobs.</div>'}</div>`; return; }
    if (activeTab === 'admin-users') { $('#adminUsersData').innerHTML=`<div class="server-list">${(state.users||[]).map(u=>`<div class="server-row"><div><h3>${escapeHtml(u.username)}</h3><p class="muted">${escapeHtml(u.email||'')} • ${escapeHtml(u.role||'user')} • ${escapeHtml(u.status||'active')} • ${state.servers.filter(s=>s.ownerId===u.id).length} servers</p></div></div>`).join('')}</div>`; return; }
    const dataRoutes = {
      'admin-servers':['/api/admin/servers','adminServersData','servers'], 'admin-nodes':['/api/admin/nodes','adminNodesData','nodes'], 'admin-locations':['/api/admin/locations','adminLocationsData','locations'], 'admin-allocations':['/api/admin/allocations','adminAllocationsData','allocations'],
      'admin-health':['/api/admin/diagnostics','adminHealthData','diagnostics']
    };
    if (dataRoutes[activeTab]) { const [url,id,key]=dataRoutes[activeTab]; const p=await api(url); const rows=p[key]||[]; document.getElementById(id).innerHTML=rows.length?`<table class="admin-table"><thead><tr>${Object.keys(rows[0]).slice(0,8).map(k=>`<th>${escapeHtml(k)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${Object.keys(rows[0]).slice(0,8).map(k=>`<td>${escapeHtml(r[k]===null||r[k]===undefined?'—':typeof r[k]==='object'?JSON.stringify(r[k]):r[k])}</td>`).join('')}</tr>`).join('')}</tbody></table>`:`<div class="empty-state">No ${escapeHtml(key)} available.</div>`; return; }
    const staticIds = ['admin-software','admin-databases','admin-backups','admin-schedules','admin-activity','admin-logs','admin-audit','admin-api','admin-webhooks','admin-notifications','admin-branding','admin-maintenance','admin-updates'];
    if (staticIds.includes(activeTab)) { const id=document.querySelector('#'+({'admin-software':'adminSoftwareData','admin-databases':'adminDatabasesData','admin-backups':'adminBackupsData','admin-schedules':'adminSchedulesData','admin-activity':'adminActivityData','admin-logs':'adminLogsData','admin-audit':'adminAuditData','admin-api':'adminApiData','admin-webhooks':'adminWebhooksData','admin-notifications':'adminNotificationsData','admin-branding':'adminBrandingData','admin-maintenance':'adminMaintenanceData','admin-updates':'adminUpdatesData'}[activeTab])); if(id) id.innerHTML=`<div class="admin-custom-grid">${['Real backend integration','RBAC protected','Audit ready','Environment aware','No fake metrics','Responsive UI'].map(x=>`<article class="panel-card"><strong>${x}</strong><p class="muted">Ready for connected configuration and operational data.</p></article>`).join('')}</div>`; return; }
    if (activeTab === 'admin-customize') { const p=await api('/api/admin/settings/full'); const settings=p.settings.adminCustomization||{}; $('#adminCustomizeData').innerHTML=Object.entries(settings).map(([k,v])=>`<label class="checkbox-row"><input type="checkbox" data-custom-key="${escapeHtml(k)}" ${v?'checked':''}>${escapeHtml(k)}</label>`).join(''); $('#saveCustomizationBtn').onclick=async()=>{const body={}; $$('#adminCustomizeData [data-custom-key]').forEach(el=>body[el.dataset.customKey]=el.checked); await api('/api/admin/customization',{method:'POST',body}); toast('Customization saved','Nebula configuration updated.');}; return; }
  } catch(e) { const el=document.querySelector('[id$="Data"]'); if(el) el.innerHTML=`<div class="empty-state"><h2>Unable to load</h2><p class="muted">${escapeHtml(e.message)}</p></div>`; }
}

function renderFiles(server) {
  const entries = filesInCurrentFolder(server);
  const currentPath = cleanUiPath(fileBrowser.path);
  return `
    <div class="control-grid">
      <form class="stack-form control-panel" data-file-save-form data-id="${escapeHtml(server.id)}">
        <div class="section-header compact"><h2>File Editor</h2><button class="primary-button" type="submit" data-save-file-button>${icon("folder")}Save</button></div>
        <label>Path<input name="path" value="${escapeHtml(fileEditor.path)}" placeholder="Click Edit on a file"></label>
        <label>Content<textarea name="content" rows="12" placeholder="File content opens here">${escapeHtml(fileEditor.content)}</textarea></label>
      </form>
      <div class="file-toolbox">
        <form class="stack-form control-panel" data-folder-form data-id="${escapeHtml(server.id)}">
          <h2>Create Folder</h2>
          <label>Path<input name="path" placeholder="${escapeHtml(joinUiPath(currentPath, "new-folder"))}"></label>
          <button class="ghost-button" type="submit">${icon("plus")}Create</button>
        </form>
        <form class="stack-form control-panel" data-upload-form data-id="${escapeHtml(server.id)}">
          <h2>Upload</h2>
          <label>Target folder<input name="targetPath" value="${escapeHtml(currentPath)}"></label>
          <label>Files<input name="files" type="file" multiple></label>
          <label>Folder<input name="folderFiles" type="file" webkitdirectory multiple></label>
          <button class="primary-button" type="submit" data-upload-button>${icon("folder")}Upload</button>
        </form>
      </div>
    </div>
    <div class="file-browser-head">
      <div>
        <p class="eyebrow">Current folder</p>
        <h2>/${escapeHtml(currentPath === "." ? "" : currentPath)}</h2>
      </div>
      <div class="row-actions">
        <button class="mini-button" data-action="folder-open" data-id="${escapeHtml(server.id)}" data-path=".">${icon("server")}Root</button>
        <button class="mini-button" data-action="folder-open" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(parentUiPath(currentPath))}" ${currentPath === "." ? "disabled" : ""}>${icon("restart")}Up</button>
      </div>
    </div>
    <div class="file-list">
      ${entries.map((file) => `
        <div class="file-item">
          <span>${escapeHtml(file.label || file.name)} <small class="muted">${escapeHtml(file.type)}</small></span>
          <div class="row-actions">
            ${file.type === "Folder" ? `<button class="mini-button" data-action="folder-open" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(file.name.replace(/\/$/, ""))}">${icon("folder")}Open</button>` : ""}
            ${isZipFile(file) ? `<button class="mini-button" data-action="zip-open" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(file.name)}">${icon("layer")}Open ZIP</button><button class="mini-button" data-action="zip-extract" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(file.name)}">${icon("backup")}Extract</button>` : ""}
            ${file.type === "Folder" ? "" : `<button class="mini-button" data-action="file-load" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(file.name)}">${icon("code")}Edit</button>`}
            <button class="mini-button" data-action="file-delete" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(file.name.replace(/\/$/, ""))}">${icon("ban")}Delete</button>
            <span class="muted">${escapeHtml(file.size)}</span>
          </div>
        </div>
      `).join("") || `<div class="file-item"><span>This folder is empty</span><span class="muted">empty</span></div>`}
    </div>
    ${renderZipViewer(server)}
  `;
}

function renderZipViewer(server) {
  if (!zipViewer.zipPath) return "";
  const dir = cleanUiPath(zipViewer.dir || ".");
  return `
    <article class="panel-card zip-viewer">
      <div class="section-header">
        <div>
          <p class="eyebrow">ZIP Browser</p>
          <h2>${escapeHtml(zipViewer.zipPath)} ${dir === "." ? "" : `/ ${escapeHtml(dir)}`}</h2>
        </div>
        <div class="row-actions">
          <button class="mini-button" data-action="zip-open" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(zipViewer.zipPath)}" data-dir="${escapeHtml(parentUiPath(dir))}" ${dir === "." ? "disabled" : ""}>${icon("restart")}Up</button>
          <button class="mini-button" data-action="zip-extract" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(zipViewer.zipPath)}">${icon("backup")}Extract all</button>
          <button class="mini-button" data-action="zip-close">${icon("ban")}Close</button>
        </div>
      </div>
      <div class="file-list">
        ${zipViewer.entries.map((entry) => `
          <div class="file-item">
            <span>${escapeHtml(entry.label || entry.name)} <small class="muted">${escapeHtml(entry.type)}</small></span>
            <div class="row-actions">
              ${entry.type === "Folder" ? `<button class="mini-button" data-action="zip-open" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(zipViewer.zipPath)}" data-dir="${escapeHtml(entry.name.replace(/\/$/, ""))}">${icon("folder")}Open</button>` : `<button class="mini-button" data-action="zip-preview" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(zipViewer.zipPath)}" data-entry="${escapeHtml(entry.name)}">${icon("code")}Preview</button><button class="mini-button" data-action="zip-extract" data-id="${escapeHtml(server.id)}" data-path="${escapeHtml(zipViewer.zipPath)}" data-entry="${escapeHtml(entry.name)}">${icon("backup")}Extract</button>`}
              <span class="muted">${escapeHtml(entry.size)}</span>
            </div>
          </div>
        `).join("") || `<div class="file-item"><span>No zip entries</span><span class="muted">empty</span></div>`}
      </div>
      ${zipViewer.previewEntry ? `<div class="zip-preview"><div class="section-header compact"><h2>${escapeHtml(zipViewer.previewEntry)}</h2></div><pre>${escapeHtml(zipViewer.previewContent)}</pre></div>` : ""}
    </article>
  `;
}

function renderSettings(server) {
  return `
    <form class="stack-form control-panel identity-panel" data-identity-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Server Icon and MOTD</h2><button class="primary-button" type="submit">${icon("server")}Save identity</button></div>
      <div class="identity-grid">
        <img class="server-icon xl" src="${escapeHtml(serverIcon(server))}" alt="">
        <div class="stack-form">
          <label>Upload PNG icon<input name="iconFile" type="file" accept="image/png"></label>
          <label>Icon URL<input name="iconUrl" value="${server.icon && !server.icon.startsWith("data:") ? escapeHtml(server.icon) : ""}"></label>
        </div>
      </div>
      <label>Custom MOTD<textarea name="motd" rows="3">${escapeHtml(server.motd || state.settings.motd)}</textarea></label>
    </form>
    <form class="stack-form control-panel" data-server-settings-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Server Settings</h2><button class="primary-button" type="submit">${icon("settings")}Save</button></div>
      <div class="form-grid">
        <label>Name<input name="name" value="${escapeHtml(server.name)}"></label>
        <label>MOTD<input name="motd" value="${escapeHtml(server.motd || state.settings.motd)}"></label>
      </div>
      <div class="form-grid">
        <label>RAM GB<input name="ram" type="number" value="${server.ram}"></label>
        <label>CPU %<input name="cpu" type="number" value="${server.cpu}"></label>
      </div>
      <div class="form-grid">
        <label>Disk GB<input name="disk" type="number" value="${server.disk}"></label>
        <label>Slots<input name="slots" type="number" value="${server.options?.slots || 60}"></label>
      </div>
      <div class="form-grid">
        <label>Gamemode<select name="gamemode"><option ${selected("survival", server.options?.gamemode)}>survival</option><option ${selected("creative", server.options?.gamemode)}>creative</option><option ${selected("adventure", server.options?.gamemode)}>adventure</option></select></label>
        <label>Difficulty<select name="difficulty"><option ${selected("peaceful", server.options?.difficulty)}>peaceful</option><option ${selected("easy", server.options?.difficulty)}>easy</option><option ${selected("normal", server.options?.difficulty)}>normal</option><option ${selected("hard", server.options?.difficulty)}>hard</option></select></label>
      </div>
      <div class="form-grid">
        <label>Spawn protection<input name="spawnProtection" type="number" value="${server.options?.spawnProtection ?? 16}"></label>
        <label>Timezone<input name="timezone" value="${escapeHtml(server.options?.timezone || "Asia/Kolkata")}"></label>
      </div>
      <div class="toggle-grid">
        ${["whitelist", "pvp", "commandBlocks", "cracked", "fly", "monsters", "animals", "nether"].map((key) => `<label class="checkbox-row"><input name="${key}" type="checkbox" ${checked(server.options?.[key])}> ${key}</label>`).join("")}
      </div>
    </form>
  `;
}

function renderNetwork(server) {
  return `
    <form class="stack-form control-panel" data-network-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Network</h2><button class="primary-button" type="submit">${icon("network")}Add port</button></div>
      <div class="form-grid"><label>Port<input name="port" type="number" placeholder="25566"></label><label class="checkbox-row"><input name="primary" type="checkbox"> Set primary</label></div>
    </form>
    <div class="settings-list">
      <div class="setting-item"><span>Primary allocation</span><strong>${escapeHtml(server.allocation)}</strong></div>
      ${server.ports.map((port) => `<div class="setting-item"><span>Port</span><div class="row-actions"><strong>${escapeHtml(port)}</strong><button class="mini-button" data-action="remove-resource" data-id="${escapeHtml(server.id)}" data-type="port" data-value="${escapeHtml(port)}">${icon("ban")}Remove</button></div></div>`).join("")}
    </div>
  `;
}

function renderDatabases(server) {
  return `
    <form class="stack-form control-panel" data-database-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Databases</h2><button class="primary-button" type="submit">${icon("database")}Add</button></div>
      <div class="form-grid"><label>Name<input name="name"></label><label>User<input name="user"></label></div>
      <label>Host<input name="host" value="localhost"></label>
    </form>
    <div class="settings-list">${server.databases.map((db) => `<div class="setting-item"><span>${escapeHtml(db.name)} <small class="muted">${escapeHtml(db.host)}</small></span><div class="row-actions"><strong>${escapeHtml(db.user)}</strong><button class="mini-button" data-action="remove-resource" data-id="${escapeHtml(server.id)}" data-type="database" data-resource-id="${escapeHtml(db.id)}">${icon("ban")}Remove</button></div></div>`).join("")}</div>
  `;
}

function renderSchedules(server) {
  return `
    <form class="stack-form control-panel" data-schedule-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Schedules</h2><button class="primary-button" type="submit">${icon("calendar")}Add</button></div>
      <div class="form-grid"><label>Name<input name="name"></label><label>Cron<input name="cron" value="0 4 * * *"></label></div>
      <label>Action<select name="action"><option>restart</option><option>backup</option><option>stop</option><option>start</option><option>command:say Scheduled message</option></select></label>
    </form>
    <div class="settings-list">${server.schedules.map((schedule) => `<div class="setting-item"><span>${escapeHtml(schedule.name)} <small class="muted">${escapeHtml(schedule.cron)}</small></span><div class="row-actions"><strong>${escapeHtml(schedule.action)}</strong><button class="mini-button" data-action="remove-resource" data-id="${escapeHtml(server.id)}" data-type="schedule" data-resource-id="${escapeHtml(schedule.id)}">${icon("ban")}Remove</button></div></div>`).join("")}</div>
  `;
}

function renderUsers(server) {
  return `
    <form class="stack-form control-panel" data-subuser-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Users</h2><button class="primary-button" type="submit">${icon("users")}Add</button></div>
      <div class="form-grid"><label>Name<input name="name"></label><label>Role<input name="role" value="Moderator"></label></div>
      <label>Permissions<input name="permissions" value="Start, Stop, Console, Files, Backups, Players"></label>
    </form>
    <div class="settings-list">${server.subusers.map((user) => `<div class="setting-item"><span>${escapeHtml(user.name)} <small class="muted">${escapeHtml(user.role)}</small></span><div class="row-actions"><strong>${escapeHtml(user.permissions?.join(", ") || user.role)}</strong><button class="mini-button" data-action="remove-resource" data-id="${escapeHtml(server.id)}" data-type="subuser" data-name="${escapeHtml(user.name)}">${icon("ban")}Remove</button></div></div>`).join("")}</div>
  `;
}

function renderBackups(server) {
  return `
    <div class="section-header compact"><h2>Backups</h2><button class="primary-button" data-action="backup-server" data-id="${escapeHtml(server.id)}">${icon("backup")}Create backup</button></div>
    <div class="file-list">${server.backups.map((backup) => `<div class="file-item"><span>${escapeHtml(backup.name)}</span><span class="muted">${escapeHtml(backup.size)}</span></div>`).join("") || `<div class="file-item"><span>No backups yet</span><span class="muted">empty</span></div>`}</div>
  `;
}

function renderStartup(server) {
  const paperVersion = selectedPaperVersion(server);
  return `
    <form class="stack-form control-panel" data-startup-form data-id="${escapeHtml(server.id)}">
      <div class="section-header compact"><h2>Startup</h2><button class="primary-button" type="submit">${icon("code")}Save</button></div>
      <div class="form-grid">
        <label>Runtime image<input name="image" value="${escapeHtml(server.startup.image)}"></label>
        <label>Paper version<select name="paperVersion" class="paper-version-select" data-selected="${escapeHtml(paperVersion)}">${paperVersionOptions(paperVersion)}</select></label>
      </div>
      <label>Command<textarea name="command" rows="3">${escapeHtml(server.startup.command)}</textarea></label>
      <label>Variables<textarea name="variablesText" rows="8">${escapeHtml(variablesText(server.startup.variables))}</textarea></label>
    </form>
  `;
}

function renderInstaller(type) {
  const server = selectedServer();
  const catalog = type === "plugin" ? state.pluginCatalog : state.modCatalog;
  return `
    <article class="panel-card search-panel">
      <div class="section-header"><div><p class="eyebrow">${type === "plugin" ? "Plugin Installer" : "Mod Management"}</p><h2>Search online repositories</h2></div><span class="status-pill">Modrinth + Spiget</span></div>
      <form class="search-form" data-search-form data-type="${type}">
        <label>Search<input name="query" placeholder="${type === "plugin" ? "luckperms, worldedit" : "sodium, create"}"></label>
        <label>Loader<select name="loader"><option value="${type === "plugin" ? "paper" : "fabric"}">${type === "plugin" ? "Paper" : "Fabric"}</option><option>bukkit</option><option>spigot</option><option>purpur</option><option>forge</option><option>neoforge</option><option value="">Any</option></select></label>
        <label>Version<input name="gameVersion" placeholder="1.21.4"></label>
        <label>Source<select name="source"><option value="all">All</option><option value="modrinth">Modrinth</option><option value="spiget">Spiget</option></select></label>
        <button class="primary-button" type="submit">${icon("search")}Search</button>
      </form>
      <div class="catalog-grid search-results">${renderSearchResults()}</div>
    </article>
    <div class="catalog-grid">
      ${catalog.map((item) => renderCatalogItem(item, type, server)).join("")}
    </div>
  `;
}

function renderSearchResults() {
  if (!searchResults.length) return `<div class="search-empty"><p class="muted">${escapeHtml(searchStatus)}</p></div>`;
  return searchResults.map((item, index) => `
    <div class="catalog-item external-item">
      <div class="catalog-top">
        <div class="external-icon">${item.iconUrl ? `<img src="${escapeHtml(item.iconUrl)}" alt="">` : icon(item.type === "plugin" ? "package" : "code", "catalog-svg")}</div>
        <div><h3>${escapeHtml(item.name)}</h3><div class="catalog-meta"><span>${escapeHtml(item.source)}</span><span>${escapeHtml(item.type)}</span><span>${Number(item.downloads || 0).toLocaleString("en-IN")} downloads</span></div></div>
        <span class="catalog-badge">${escapeHtml(item.version || "latest")}</span>
      </div>
      <p class="muted">${escapeHtml(item.description)}</p>
      <button class="primary-button wide" data-action="install-external" data-index="${index}">${icon(item.type === "plugin" ? "package" : "code")}Install</button>
    </div>
  `).join("");
}

function renderCatalogItem(item, type, server) {
  const list = type === "plugin" ? server.plugins : server.mods;
  const installed = list.includes(item.name);
  return `
    <div class="catalog-item">
      <div class="catalog-top">
        <div class="catalog-icon ${type}">${icon(item.icon || (type === "plugin" ? "package" : "code"), "catalog-svg")}</div>
        <div><h3>${escapeHtml(item.name)}</h3><div class="catalog-meta"><span>v${escapeHtml(item.version)}</span><span>${type}</span></div></div>
        <span class="catalog-badge">${installed ? "Installed" : "Ready"}</span>
      </div>
      <p class="muted">${escapeHtml(item.description)}</p>
      <button class="${installed ? "ghost-button" : "primary-button"} wide" ${installed ? "disabled" : ""} data-action="install-content" data-type="${type}" data-id="${escapeHtml(item.id)}">${icon(type === "plugin" ? "package" : "code")}${installed ? "Installed" : "Install"}</button>
    </div>
  `;
}

function renderPlayers(server) {
  const players = state.players.filter((player) => player.serverId === server.id);
  return `
    <div class="players-layout">
      <article class="panel-card">
        <div class="section-header"><h2>Player Management</h2><button class="ghost-button" id="syncPlayersBtn" type="button">${icon("users")}Sync</button></div>
        <div class="player-table">${players.map((player) => `<div class="player-row"><div><h3>${escapeHtml(player.name)}</h3><div class="player-meta"><span>${escapeHtml(player.role)}</span><span>${escapeHtml(player.status)}</span><span>${player.whitelisted ? "whitelisted" : "not whitelisted"}</span></div></div><div class="player-actions"><button class="mini-button" data-action="player" data-player-action="op" data-id="${escapeHtml(player.id)}">${icon("shield")}OP</button><button class="mini-button" data-action="player" data-player-action="whitelist" data-id="${escapeHtml(player.id)}">${icon("users")}Whitelist</button><button class="mini-button" data-action="player" data-player-action="kick" data-id="${escapeHtml(player.id)}">${icon("stop")}Kick</button><button class="mini-button" data-action="player" data-player-action="ban" data-id="${escapeHtml(player.id)}">${icon("ban")}Ban</button><button class="mini-button" data-action="player" data-player-action="delete" data-id="${escapeHtml(player.id)}">${icon("ban")}Remove</button></div></div>`).join("")}</div>
      </article>
      <article class="panel-card">
        <form class="stack-form" id="addPlayerForm">
          <h2>Add player</h2>
          <label>Name<input name="name"></label>
          <label>Role<select name="role"><option>Member</option><option>Builder</option><option>Moderator</option><option>Operator</option><option>Owner</option></select></label>
          <label class="checkbox-row"><input name="whitelisted" type="checkbox" checked> Whitelist</label>
          <button class="primary-button" type="submit">${icon("users")}Add player</button>
        </form>
        <form class="stack-form broadcast-form" id="broadcastForm">
          <h2>Broadcast</h2>
          <label>Message<textarea name="message" rows="4"></textarea></label>
          <button class="ghost-button" type="submit">${icon("send")}Send broadcast</button>
        </form>
      </article>
    </div>
  `;
}

function renderActivity(server) {
  const items=(state.activity||[]).slice(0,100);
  return `<article class="panel-card"><div class="section-header"><div><p class="eyebrow">Audit-ready activity</p><h2>Server Activity</h2></div><span class="muted">Latest 100 events</span></div><div class="activity-feed">${items.map(x=>`<div class="activity-item">${escapeHtml(x)}</div>`).join('')||`<div class="empty-state">No activity yet.</div>`}</div></article>`;
}

function renderEnvironment(server) {
  const env = server.environment || { environment: 'local-java', config: {} };
  const r = state.runtime || {};
  const envs=[
    ['local-java','Local Process',true,'Native Node-controlled Java process; Docker/systemd not required.'],
    ['docker','Docker',!!r.docker,'Optional container backend; detected from the current host.'],
    ['systemd','systemd',!!r.systemd,'Optional Linux service integration; only used when available and permitted.'],
    ['ttyd','ttyd / container',!!r.ttyd || !!r.isContainer,'Compatible with ttyd/container environments via Local Process fallback.']
  ];
  return `<div class="environment-layout">
    <article class="panel-card"><div class="section-header"><div><p class="eyebrow">Environment Manager</p><h2>Runtime Detection</h2></div><span class="status-pill">${escapeHtml(r.label||'Detected')}</span></div>
      <div class="health-grid">${envs.map(([id,label,ok,desc])=>`<div class="health-chip ${ok?'ok':'off'}"><i></i><span><strong>${escapeHtml(label)}</strong><small class="muted">${escapeHtml(desc)}</small></span><b>${ok?'Ready':'Unavailable'}</b></div>`).join('')}</div>
    </article>
    <article class="panel-card"><div class="section-header"><div><p class="eyebrow">Backend Selection</p><h2>Actual execution backend</h2></div></div>
      <form class="stack-form" id="environmentForm"><label>Backend<select name="environment">${envs.filter(([,_,ok])=>ok).map(([id,label])=>`<option value="${id}" ${selected(env.environment,id)}>${escapeHtml(label)}</option>`).join('')}</select></label>
      <div class="form-grid"><label>Port<input name="port" type="number" value="${escapeHtml((env.config?.port||String(server.allocation||'').split(':').pop()||25565))}"></label><label>Bind address<input name="bind" value="${escapeHtml(env.config?.bind||'127.0.0.1')}"></label></div>
      <label>Custom Config JSON<textarea name="customConfig" rows="6">${escapeHtml(JSON.stringify(env.config||{},null,2))}</textarea></label><button class="primary-button wide" type="submit">${icon('server')}Apply Backend</button></form>
    </article>
    <article class="panel-card"><div class="section-header"><div><p class="eyebrow">Host</p><h2>Capacity</h2></div></div><div class="dashboard-strip">${dashboardStat('CPU',r.cpuCount||'Unavailable','activity')}${dashboardStat('RAM',r.totalMemoryMB?Math.round(r.totalMemoryMB/1024)+' GB':'Unavailable','server')}${dashboardStat('Java',r.java?(r.javaVersion||'Available'):'Unavailable','code')}${dashboardStat('Docker',r.docker?'Ready':'Unavailable','server')}</div></article>
  </div>`;
}

function renderDownload(server) {
  const features = state.settings.features || {};
  
  return `
    <div class="download-layout">
      <article class="panel-card">
        <div class="section-header">
          <h2>Server Download</h2>
          <span class="status-pill ${features.serverDownload ? 'success' : 'disabled'}">${features.serverDownload ? 'Enabled' : 'Disabled'}</span>
        </div>
        
        <div class="download-info">
          <p class="muted">Download your entire server folder as a compressed archive. This includes all world data, plugins, configurations, and player data.</p>
        </div>
        
        <div class="download-options">
          <div class="download-option">
            <h3>${icon("folder")}Full Server</h3>
            <p class="muted">Complete server directory with all files</p>
            <div class="download-meta">
              <span>~${server.disk} GB</span>
              <span>All files</span>
            </div>
            <button class="primary-button wide" data-action="download-server" data-type="full">${icon("download")}Download Full Server</button>
          </div>
          
          <div class="download-option">
            <h3>${icon("folder")}World Only</h3>
            <p class="muted">Only world files and region data</p>
            <div class="download-meta">
              <span>~${Math.round(server.disk * 0.7)} GB</span>
              <span>World files</span>
            </div>
            <button class="ghost-button wide" data-action="download-server" data-type="world">${icon("download")}Download World</button>
          </div>
          
          <div class="download-option">
            <h3>${icon("folder")}Config Only</h3>
            <p class="muted">Configuration files and plugins</p>
            <div class="download-meta">
              <span>~${Math.round(server.disk * 0.1)} GB</span>
              <span>Config files</span>
            </div>
            <button class="ghost-button wide" data-action="download-server" data-type="config">${icon("download")}Download Config</button>
          </div>
        </div>
        
        <div class="download-status">
          <p class="eyebrow">Download Status</p>
          <div id="downloadStatus" class="status-message">
            <span class="muted">No download in progress</span>
          </div>
        </div>
      </article>
      
      <article class="panel-card">
        <div class="section-header"><h2>Download History</h2></div>
        <div class="download-history">
          ${(server.downloadHistory || []).map((download) => `
            <div class="download-history-item">
              <div>
                <h4>${escapeHtml(download.type)} - ${escapeHtml(download.date)}</h4>
                <span class="muted">${escapeHtml(download.size)}</span>
              </div>
              <span class="status-pill ${download.status === 'completed' ? 'success' : 'error'}">${escapeHtml(download.status)}</span>
            </div>
          `).join('') || '<div class="empty-state"><p class="muted">No downloads yet</p></div>'}
        </div>
      </article>
    </div>
  `;
}

function fillCreateOptions() {
  const eggSelect = $("#eggSelect");
  const providerSelect = $("#providerSelect");
  if (eggSelect) eggSelect.innerHTML = gameEggs.map((egg) => `<option>${escapeHtml(egg)}</option>`).join("");
  if (providerSelect && state) {
    const providers = state.settings.providers || {};
    providerSelect.innerHTML = providerCatalog
      .filter((provider) => providers[provider.id] ?? state.settings[provider.id])
      .map((provider) => `<option value="${provider.id}">${escapeHtml(provider.name)}</option>`)
      .join("") || providerCatalog.map((p) => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join("");
  }
  $$(".paper-version-select").forEach(fillPaperVersionSelect);
  loadPaperVersions();
}

function fillAdminForm() {
  const form = $("#adminSettingsForm");
  if (!form || !state) return;
  form.panelName.value = state.settings.panelName;
  form.theme.value = state.settings.theme || 'nebula';
  form.serverCost.value = state.settings.serverCost;
  form.maxServers.value = state.settings.maxServers;
  form.clickTarget.value = state.settings.clickTarget;
  form.clickReward.value = state.settings.clickReward;
  form.motd.value = state.settings.motd;
  form.defaultRam.value = state.settings.defaultRam || 2;
  form.defaultCpu.value = state.settings.defaultCpu || 100;
  form.defaultDisk.value = state.settings.defaultDisk || 10;
  
  for (const key of ["local", "pterodactyl", "codesandbox", "github", "vps"]) {
    form[key].checked = state.settings[key];
  }
  
  for (const key of ["localSupport", "ttydSupport", "serverDownload"]) {
    if (form[key]) form[key].checked = state.settings.features?.[key] !== false;
  }
  
  for (const key of ["advancedConsole", "realTimeStats", "autoBackups", "pluginMarketplace", "customThemes", "webTerminal"]) {
    form[key].checked = state.settings.features?.[key] || false;
  }
  
  form.sessionTimeout.value = state.settings.sessionTimeout || 60;
  form.maxLoginAttempts.value = state.settings.maxLoginAttempts || 5;
  form.requireEmailVerification.checked = state.settings.requireEmailVerification || false;
  form.enableTwoFactor.checked = state.settings.enableTwoFactor || false;
  form.consoleLineLimit.value = state.settings.consoleLineLimit || 100;
  form.fileUploadLimit.value = state.settings.fileUploadLimit || 50;
}

function fillAccountForm() {
  const form = $("#accountSettingsForm");
  if (!form || !currentUser) return;
  form.username.value = currentUser.username || "";
  form.email.value = currentUser.email || "";
  form.currentPassword.value = "";
  form.newPassword.value = "";
  form.confirmPassword.value = "";
  $("#accountSummaryName").textContent = currentUser.username || "User";
  $("#accountSummaryRole").textContent = currentUser.role || "user";
}

function toast(title, message) {
  const region = $("#toastRegion");
  const node = document.createElement("div");
  node.className = "toast";
  node.innerHTML = `<strong>${escapeHtml(title)}</strong><span>${escapeHtml(message)}</span>`;
  region.appendChild(node);
  setTimeout(() => node.remove(), 3600);
}

function bindStaticForms() {
  setInterval(async () => { const s=selectedServer(); if(s && pageMode==='panel' && activeTab==='console'){ await refreshLiveMetrics(s.id); renderContent(); } }, 5000);
  $("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    try {
      const payload = await api("/api/auth/login", {
        method: "POST",
        body: { identifier: form.get("identifier"), password: form.get("password") }
      });
      localStorage.setItem(tokenKey, payload.token);
      if (pageMode === "panel") {
        location.href = "index.html";
        return;
      }
      await refresh();
    } catch (error) {
      toast("Login failed", error.message);
    }
  });

  $("#showRegisterBtn").addEventListener("click", () => { const form=$("#registerForm"); form.classList.toggle("hidden"); form.querySelector('input[name="username"]')?.focus(); });

  $("#registerForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    try {
      const payload = await api("/api/auth/register", {
        method: "POST",
        body: { username: form.get("username"), email: form.get("email"), password: form.get("password") }
      });
      localStorage.setItem(tokenKey, payload.token);
      if (pageMode === "panel") {
        location.href = "index.html";
        return;
      }
      await refresh();
    } catch (error) {
      toast("Register failed", error.message);
    }
  });

  $("#logoutBtn").addEventListener("click", async () => {
    try { await api("/api/auth/logout", { method: "POST", body: {} }); } catch {}
    localStorage.removeItem(tokenKey);
    showAuth();
  });

  $("#serverListBtn")?.addEventListener("click", () => renderServerPicker(true));
  $("#createServerBtn")?.addEventListener("click", () => $("#createModal").classList.remove("hidden"));
  $("#adminPanelBtn")?.addEventListener("click", () => {
    if (!canUseAdmin()) {
      toast("Admin locked", "Only admin accounts can open administrator controls.");
      return;
    }
    if (pageMode === "dashboard") { location.href = "panel.html#admin-overview"; return; }
    fillAdminForm();
    $("#adminModal").classList.remove("hidden");
  });
  $("#accountSettingsBtn")?.addEventListener("click", () => {
    fillAccountForm();
    $("#accountModal").classList.remove("hidden");
  });
  $$("[data-close-modal]").forEach((button) => button.addEventListener("click", () => button.closest(".modal").classList.add("hidden")));

  document.addEventListener('keydown', (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); openCommandPalette(); }
    if (event.key === 'Escape') { $('#commandPaletteModal')?.classList.add('hidden'); }
  });
  $('#commandPaletteInput')?.addEventListener('input', renderCommandPalette);
  $('[data-close-command]')?.addEventListener('click', () => $('#commandPaletteModal')?.classList.add('hidden'));

  $("#createServerForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const body = {
      name: form.get("name"),
      egg: form.get("egg"),
      provider: form.get("provider"),
      paperVersion: form.get("paperVersion") || "latest",
      region: form.get("region"),
      runtime: form.get("runtime"),
      ram: Number(form.get("ram")),
      cpu: Number(form.get("cpu")),
      disk: Number(form.get("disk")),
      autoStart: form.get("autoStart") === "on"
    };
    try {
      await api("/api/servers", { method: "POST", body });
      $("#createModal").classList.add("hidden");
      await refresh();
      openServer(state.selectedServerId);
    } catch (error) {
      toast("Create failed", error.message);
    }
  });

  $("#adminSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!canUseAdmin()) {
      toast("Admin locked", "Only admin accounts can save these settings.");
      return;
    }
    const form = event.currentTarget;
    const body = {
      panelName: form.panelName.value,
      theme: form.theme.value,
      serverCost: Number(form.serverCost.value),
      maxServers: Number(form.maxServers.value),
      clickTarget: Number(form.clickTarget.value),
      clickReward: Number(form.clickReward.value),
      motd: form.motd.value,
      defaultRam: Number(form.defaultRam.value),
      defaultCpu: Number(form.defaultCpu.value),
      defaultDisk: Number(form.defaultDisk.value),
      local: form.local.checked,
      pterodactyl: form.pterodactyl.checked,
      codesandbox: form.codesandbox.checked,
      github: form.github.checked,
      vps: form.vps.checked,
      features: {
        localSupport: form.localSupport?.checked !== false,
        dockerSupport: Boolean(state.runtime?.docker),
        systemdSupport: Boolean(state.runtime?.systemd),
        ttydSupport: form.ttydSupport?.checked !== false,
        serverDownload: form.serverDownload.checked,
        advancedConsole: form.advancedConsole.checked,
        realTimeStats: form.realTimeStats.checked,
        autoBackups: form.autoBackups.checked,
        pluginMarketplace: form.pluginMarketplace.checked,
        customThemes: form.customThemes.checked,
        webTerminal: form.webTerminal.checked
      },
      sessionTimeout: Number(form.sessionTimeout.value),
      maxLoginAttempts: Number(form.maxLoginAttempts.value),
      requireEmailVerification: form.requireEmailVerification.checked,
      enableTwoFactor: form.enableTwoFactor.checked,
      consoleLineLimit: Number(form.consoleLineLimit.value),
      fileUploadLimit: Number(form.fileUploadLimit.value)
    };
    try {
      await api("/api/admin/settings", { method: "POST", body });
      $("#adminModal").classList.add("hidden");
      await refresh();
      toast("Admin saved", "All admin settings updated successfully.");
    } catch (error) {
      toast("Admin error", error.message);
    }
  });

  $("#accountSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.newPassword.value && form.newPassword.value !== form.confirmPassword.value) {
      toast("Account error", "New password confirmation does not match.");
      return;
    }
    const body = {
      username: form.username.value,
      email: form.email.value,
      currentPassword: form.currentPassword.value,
      newPassword: form.newPassword.value
    };
    try {
      const payload = await api("/api/account/settings", { method: "POST", body });
      if (payload.user) currentUser = payload.user;
      $("#accountModal").classList.add("hidden");
      await refresh();
      toast("Account saved", "Your profile settings were updated.");
    } catch (error) {
      toast("Account error", error.message);
    }
  });
}

function bindDelegatedActions() {
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action], [data-tab]");
    if (!button) return;
    if (button.dataset.tab) {
      setTab(button.dataset.tab);
      return;
    }
    const action = button.dataset.action;
    const id = button.dataset.id;
    try {
      if (button.id === "pickerCreateBtn" || action === "open-create") {
        $("#createModal").classList.remove("hidden");
        return;
      }
      if (action === "open-environment") {
        const server = selectedServer();
        if (!server) { toast("Environment", "Select or create a server first."); return; }
        if (pageMode !== "panel") { openServer(server.id); setTimeout(() => setTab("environment"), 50); return; }
        setTab("environment");
        return;
      }
      if (action === "click-earn") {
        await api("/api/click", { method: "POST", body: {} });
        await refresh();
        return;
      }
      if (action === "buy-server-limit") {
        await api("/api/marketplace/server-limit", { method: "POST", body: {} });
        await refresh();
        toast("Marketplace", "Server limit upgraded by 1.");
        return;
      }
      if (action === "open-server") {
        openServer(id);
        return;
      }
      if (action === "power") {
        await api(`/api/servers/${id}/power`, { method: "POST", body: { action: button.dataset.power } });
        await refresh();
        return;
      }
      if (action === "backup-server") {
        await api(`/api/servers/${id}/backup`, { method: "POST", body: {} });
        await refresh();
        return;
      }
      if (action === "folder-open") {
        const folderPath = cleanUiPath(button.dataset.path);
        const payload = await api(`/api/servers/${id}/files?path=${encodeURIComponent(folderPath)}`);
        fileBrowser = { path: payload.path, entries: payload.files || [] };
        renderContent();
        return;
      }
      if (action === "file-load") {
        const payload = await api(`/api/servers/${id}/file?path=${encodeURIComponent(button.dataset.path)}`);
        const form = $("[data-file-save-form]");
        fileEditor = { path: payload.path, content: payload.content, loaded: true };
        form.elements.path.value = payload.path;
        form.elements.content.value = payload.content;
        return;
      }
      if (action === "file-delete") {
        if (!confirm(`Delete ${button.dataset.path}?`)) return;
        await api(`/api/servers/${id}/file/delete`, { method: "POST", body: { path: button.dataset.path } });
        fileBrowser.entries = [];
        await refresh();
        return;
      }
      if (action === "zip-open") {
        const zipPath = button.dataset.path;
        const dir = button.dataset.dir || "";
        const payload = await api(`/api/servers/${id}/zip?path=${encodeURIComponent(zipPath)}&dir=${encodeURIComponent(dir)}`);
        zipViewer = { zipPath: payload.path, dir: payload.dir || "", entries: payload.entries || [], previewEntry: "", previewContent: "" };
        renderContent();
        return;
      }
      if (action === "zip-preview") {
        const payload = await api(`/api/servers/${id}/zip/file?path=${encodeURIComponent(button.dataset.path)}&entry=${encodeURIComponent(button.dataset.entry)}`);
        zipViewer.previewEntry = payload.entry;
        zipViewer.previewContent = payload.content;
        renderContent();
        return;
      }
      if (action === "zip-extract") {
        await api(`/api/servers/${id}/zip/extract`, { method: "POST", body: { path: button.dataset.path, entry: button.dataset.entry || "", targetPath: fileBrowser.path } });
        fileBrowser.entries = [];
        await refresh();
        return;
      }
      if (action === "zip-close") {
        zipViewer = { zipPath: "", dir: "", entries: [], previewEntry: "", previewContent: "" };
        renderContent();
        return;
      }
      if (action === "remove-resource") {
        await api(`/api/servers/${id}/remove`, { method: "POST", body: { type: button.dataset.type, value: button.dataset.value, id: button.dataset.resourceId, name: button.dataset.name } });
        await refresh();
        return;
      }
      if (action === "install-content") {
        const server = selectedServer();
        await api(`/api/servers/${server.id}/install`, { method: "POST", body: { type: button.dataset.type, itemId: button.dataset.id } });
        await refresh();
        return;
      }
      if (action === "install-external") {
        const server = selectedServer();
        const item = searchResults[Number(button.dataset.index)];
        const form = $("[data-search-form]");
        await api(`/api/servers/${server.id}/install-external`, { method: "POST", body: { ...item, loader: form?.elements.loader.value || "", gameVersion: form?.elements.gameVersion.value || "" } });
        await refresh();
        return;
      }
      if (action === "player") {
        await api(`/api/players/${id}/action`, { method: "POST", body: { action: button.dataset.playerAction } });
        await refresh();
        return;
      }
      if (action === "download-server") {
        const server = selectedServer();
        const downloadType = button.dataset.type || "full";
        try {
          const token = localStorage.getItem(tokenKey);
          const response = await fetch(`/api/servers/${server.id}/download?type=${encodeURIComponent(downloadType)}`, {
            headers: token ? { authorization: `Bearer ${token}` } : {}
          });
          if (!response.ok) throw new Error("Download failed");
          const blob = await response.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = `${server.name}-${downloadType}.zip`;
          a.click();
          URL.revokeObjectURL(url);
          toast("Download complete", `${downloadType} archive saved for ${server.name}`);
          const statusEl = $("#downloadStatus");
          if (statusEl) statusEl.innerHTML = `<span class="status-pill success">Download completed — ${escapeHtml(downloadType)}</span>`;
          await refresh();
        } catch (error) {
          toast("Download failed", error.message);
          const statusEl = $("#downloadStatus");
          if (statusEl) statusEl.innerHTML = `<span class="status-pill error">Download failed: ${escapeHtml(error.message)}</span>`;
        }
        return;
      }
      if (action === "generate-docker-compose") {
        const server = selectedServer();
        const dockerCompose = generateDockerCompose(server);
        // Create a downloadable file
        const blob = new Blob([dockerCompose], { type: 'text/yaml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'docker-compose.yml';
        a.click();
        URL.revokeObjectURL(url);
        toast("Docker Compose", "docker-compose.yml generated and downloaded");
        return;
      }
      if (action === "install-systemd") {
        const server = selectedServer();
        await api(`/api/servers/${server.id}/environment`, { method: "POST", body: { environment: "systemd", config: { user: "minecraft" } } });
        toast("Systemd", "Systemd service configured — start server to activate");
        await refresh();
        return;
      }
      if (action === "launch-ttyd") {
        const server = selectedServer();
        await api(`/api/servers/${server.id}/environment`, { method: "POST", body: { environment: "ttyd", config: { port: 7681 } } });
        if (server.ttydUrl) window.open(server.ttydUrl, "_blank");
        else toast("TTYd", "TTYd configured — start server then open terminal tab");
        await refresh();
        return;
      }
    } catch (error) {
      toast("Action failed", error.message);
    }
  });

  document.addEventListener("submit", async (event) => {
    const server = selectedServer();
    const form = event.target;
    try {
      if (form.id === "environmentForm") {
        event.preventDefault();
        const formData = new FormData(form);
        let customConfig = {};
        try { customConfig = JSON.parse(formData.get("customConfig") || "{}"); } catch { customConfig = {}; }
        await api(`/api/servers/${server.id}/environment`, {
          method: "POST",
          body: {
            environment: formData.get("environment"),
            config: { port: Number(formData.get("port")), user: formData.get("user"), ...customConfig }
          }
        });
        await refresh();
        toast("Environment", "Environment configuration updated");
        return;
      }
      if (form.matches("[data-command-form]")) {
        event.preventDefault();
        const command = form.elements.command.value.trim();
        if (!command) return;
        await api(`/api/servers/${form.dataset.id}/command`, { method: "POST", body: { command } });
        await refresh();
      } else if (form.matches("[data-file-save-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        const done = setButtonBusy(form.querySelector("[data-save-file-button]"), "Saving...");
        try {
          await Promise.all([
            api(`/api/servers/${form.dataset.id}/file`, { method: "POST", body: { path: data.get("path"), content: data.get("content") } }),
            delay(2000)
          ]);
        } finally {
          done();
        }
        fileEditor = { path: data.get("path"), content: data.get("content"), loaded: true };
        fileBrowser.entries = [];
        await refresh();
      } else if (form.matches("[data-folder-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/folder`, { method: "POST", body: { path: data.get("path") } });
        fileBrowser.entries = [];
        await refresh();
      } else if (form.matches("[data-upload-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        const picked = [
          ...Array.from(form.elements.files.files || []),
          ...Array.from(form.elements.folderFiles.files || [])
        ];
        if (!picked.length) {
          toast("Upload failed", "Select files or a folder first.");
          return;
        }
        const done = setButtonBusy(form.querySelector("[data-upload-button]"), "Uploading...");
        const files = [];
        for (const file of picked.slice(0, 120)) {
          files.push({
            name: file.name,
            relativePath: file.webkitRelativePath || file.name,
            dataUrl: await readFileAsDataUrl(file)
          });
        }
        try {
          await api(`/api/servers/${form.dataset.id}/upload`, { method: "POST", body: { targetPath: data.get("targetPath"), files } });
        } finally {
          done();
        }
        fileBrowser.entries = [];
        await refresh();
      } else if (form.matches("[data-identity-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        const iconDataUrl = await readFileAsDataUrl(form.elements.iconFile.files[0]);
        await api(`/api/servers/${form.dataset.id}/identity`, { method: "POST", body: { motd: data.get("motd"), iconUrl: data.get("iconUrl"), iconDataUrl } });
        await refresh();
      } else if (form.matches("[data-server-settings-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/settings`, {
          method: "POST",
          body: {
            name: data.get("name"), motd: data.get("motd"), ram: Number(data.get("ram")), cpu: Number(data.get("cpu")), disk: Number(data.get("disk")),
            slots: Number(data.get("slots")), gamemode: data.get("gamemode"), difficulty: data.get("difficulty"), spawnProtection: Number(data.get("spawnProtection")),
            timezone: data.get("timezone"), whitelist: data.get("whitelist") === "on", pvp: data.get("pvp") === "on", commandBlocks: data.get("commandBlocks") === "on",
            cracked: data.get("cracked") === "on", fly: data.get("fly") === "on", monsters: data.get("monsters") === "on", animals: data.get("animals") === "on", nether: data.get("nether") === "on"
          }
        });
        await refresh();
      } else if (form.matches("[data-network-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/network`, { method: "POST", body: { port: data.get("port"), primary: data.get("primary") === "on" } });
        await refresh();
      } else if (form.matches("[data-database-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/databases`, { method: "POST", body: { name: data.get("name"), user: data.get("user"), host: data.get("host") } });
        await refresh();
      } else if (form.matches("[data-schedule-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/schedules`, { method: "POST", body: { name: data.get("name"), cron: data.get("cron"), action: data.get("action") } });
        await refresh();
      } else if (form.matches("[data-startup-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/startup`, { method: "POST", body: { image: data.get("image"), command: data.get("command"), paperVersion: data.get("paperVersion"), variablesText: data.get("variablesText") } });
        await refresh();
      } else if (form.matches("[data-subuser-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${form.dataset.id}/subusers`, { method: "POST", body: { name: data.get("name"), role: data.get("role"), permissions: data.get("permissions") } });
        await refresh();
      } else if (form.matches("[data-search-form]")) {
        event.preventDefault();
        const data = new FormData(form);
        searchStatus = "Searching...";
        searchResults = [];
        renderContent();
        const params = new URLSearchParams({ query: data.get("query"), type: form.dataset.type, loader: data.get("loader"), gameVersion: data.get("gameVersion"), source: data.get("source"), limit: "12" });
        const payload = await api(`/api/catalog/search?${params.toString()}`);
        searchResults = payload.results || [];
        searchStatus = searchResults.length ? `Found ${searchResults.length} results.` : "No results found.";
        renderContent();
      } else if (form.id === "addPlayerForm") {
        event.preventDefault();
        const data = new FormData(form);
        await api(`/api/servers/${server.id}/players`, { method: "POST", body: { name: data.get("name"), role: data.get("role"), whitelisted: data.get("whitelisted") === "on" } });
        await refresh();
      } else if (form.id === "broadcastForm") {
        event.preventDefault();
        const data = new FormData(form);
        await api("/api/broadcast", { method: "POST", body: { message: data.get("message") } });
        await refresh();
      }
    } catch (error) {
      toast("Save failed", error.message);
    }
  });
}

async function init() {
  bindStaticForms();
  bindDelegatedActions();
  activeTab = location.hash.replace("#", "") || "console";
  if (!localStorage.getItem(tokenKey)) {
    showAuth();
    return;
  }
  try {
    await refresh();
  } catch {
    localStorage.removeItem(tokenKey);
    showAuth();
  }
  setInterval(() => {
    const shell = pageMode === "dashboard" ? $("#dashboardShell") : pageMode === "marketplace" ? $("#marketplaceShell") : $("#panelShell");
    if (shell && !shell.classList.contains("hidden")) refresh().catch(() => {});
  }, 8000);
}

init();
