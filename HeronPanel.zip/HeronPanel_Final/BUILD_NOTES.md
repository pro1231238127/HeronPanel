# HeronPanel Advanced Nebula Build

- Default panel port: 6767
- Admin username: admin
- Admin email: admin@heronpanel.dev
- Admin password: Heron@6767!Panel#2026
- New account registration: enabled
- New server storage: servers/users/<user-id>/servers/<server-id>/
- Legacy servers/<server-id>/ remains supported as a compatibility fallback.
- Docker/systemd remain optional; Local Process remains the fallback runtime.

Security note: the password is stored only as a password hash in panel-state.json; change it from Account settings after first login.
