# Changelog

## 4.0.0 — Portable Nebula
- Removed Docker/systemd as runtime requirements.
- Minecraft servers launch directly with Java from Node.js child processes.
- Added all-interface binding for VPS, CodeSandbox and Codespaces.
- Added auto-start restoration for servers marked Auto Start.
- Added safer restart error handling.
- Kept the supplied background video and existing panel assets.
- Switched default Nebula base palette to black/white.
- Removed npm runtime dependencies; the panel uses Node's built-in HTTP APIs.
